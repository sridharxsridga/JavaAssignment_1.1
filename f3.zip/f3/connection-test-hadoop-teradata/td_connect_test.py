# -*- coding: utf-8 -*-
"""
Created on Mon Aug 20 13:13:26 2018

@author: 29899
"""

from dsspy import connections as dc
from dsspy import logging as dsl
import os
import warnings
import argparse
try:
    import jks
except:
    warnings.warn('No JKS module found. JKS functionality unavailable', ImportWarning)
    have_jks = False
else:
    have_jks = True


    
def tdConnectionTest(args, num_mappers = 4, storepass = 'none'):
    '''
    Tests the connection between Teradata and Hadoop
    Exports the hive table to Teradata. 
    It validates that the record counts are the same on the hive and Teradata sides post sqoop. 
    :param str args: The arguments passed
    :param str num_mappers: The number of mappers (parallel processes) to use on the hadoop side. Defaults to 4
    :param str storepass: the keystore password
    :return int: 0 for a successful sqoop load. 1 for a failure
    '''
    
    keystore = args.jceks
    jceks = 'jceks://file'+args.jceks
    ks = jks.KeyStore.load(keystore, storepass).secret_keys
    tdUser = ks['sqoop.user'].key.decode('utf-8')
    
    #TODO: Provide log file path
    logger = dsl.getLogger(appname = "Teradata Connection Test", log_file=None)
    
    #EDW details
    edwHost = args.edwHostName
    edwDatabase = args.edwDatabaseName
    edwTable = args.edwTableName
    
    #Hive Details
    hiveHost = args.hiveHostName
    hiveDatabase = args.hiveDatabaseName
    hiveTable = args.hiveTableName
    
    libpath="/usr/iop/4.2.5.0-0000/sqoop/lib/teradata-connector-1.5.3.jar"
    
    edwCountStmt = "SELECT COUNT(*) FROM " + edwDatabase + "." + edwTable + ";"
    edwDeleteStmt = "DELETE FROM  " + edwDatabase + "." + edwTable + ";"
    hiveCountStmt = "SELECT COUNT(*) FROM " + hiveDatabase + "." + hiveTable + ";"
    
    #Testing teradata connection:
    try:
        edwPreCount = dc.sqoop_eval(libpath, edwHost,'sqoop.user', 'sqoop.password', edwDatabase, edwCountStmt, keystore = args.jceks)
        logger.info('EDW pre-sqoop record count : ' + str(edwPreCount))
    except Exception as e:
        logger.error(str(e))
        logger.error('Cannot access Teradata table to count')
        result = 1
        return result
    
    #Truncating the EDW table
    delete = run_edw_stmts(libpath, edwHost, tdUser, edwDatabase, edwDeleteStmt, args)
    if delete !=0:
        logger.warn('Data is not truncated in EDW table')
    else:
        logger.info('Data truncated in EDW table')
        
    #counting records in hive table
    hiveCount = get_count(hiveCountStmt ,hiveHost,'bigsql.user', 'bigsql.password', keystore = args.jceks)
    
    #Sqooping data from Hive table to Teradata
    sqoop_bash = '''
        sqoop tdexport -Dteradata.db.output.source.database='''+hiveDatabase+''' \
        -Dtdch.input.timestamp.format="yyyy-MM-dd HH:mm:ss" \
        -Dhadoop.security.credential.provider.path='''+jceks+''' \
        -Dteradata.db.output.method=internal.fastload \
        --connect jdbc:teradata://'''+edwHost+'''/database='''+edwDatabase+''',CLIENT_CHARSET=ISO8859_1 \
        --username '''+tdUser+''' \
        --password-alias 'sqoop.password' \
        --hive-table '''+hiveTable+''' \
        --table '''+edwTable+''' \
        --num-mappers '''+str(num_mappers)+'''
            '''
    logger.info(sqoop_bash)  
    rt = os.system(sqoop_bash) # run the sqoop job
    if rt !=0:
        raise(Exception('Sqoop error'))
        
    #Check for coounts    
    edwPostCount = dc.sqoop_eval(libpath, edwHost,'sqoop.user', 'sqoop.password', edwDatabase, edwCountStmt, keystore = args.jceks)
    logger.info('Hive record count : ' + str(hiveCount))
    logger.info('EDW record count : ' + str(edwPostCount))
    
    #Error if count doesn't match
    if edwPostCount != hiveCount:
        logger.error('Sqoop validation error: \nRecord counts do not match')
        result = 1
    else:
        result = rt
    
    logger.info("Exit code is "+ str(result))
    return result
      

def get_count(stmt,hostname,user,pwd, keystore= None):
    '''
    Runs a count(*) sql statment on hive (or Teradata, but connector currently doesn't work for Teradata) and returns a formated count as an integer

    :param str stmt: The sql statement to run
    :param str hostname: the Hadoop/Teradata hostname to use. See dsspy docs section on run_sql for correct use
    :param str user: The username the run the sql statement under
    :param str pwd: The corresponding password for the above username
    :param str keystore: The java keystore containing the username and password of the user to run the sql queries. Defaults to None. 
    
    :return int: The count
    '''
    data = int(dc.run_sql(stmt, hostname, user , pwd, keystore, getdata=True).values)
    return data
 

def run_edw_stmts(libpath, edw_hostname, keyuser, edw_db, edw_stmt, args):
    '''
    Designed to run deletes of the IM tables and then inserts into main tables

    :params str libpath: The path to the Teradata connector jar, currently passed in from sqooper.py. 
    :params str edw_hostname: The url for the Teradata box, i.e. BCP vs Prod
    :params str keyuser: The username to use when running the update statement. Currently it should be passed down from sqooper.py
    :params str edw_db: The database to connect to on Teradata
    :params str edw_stmt: The statement to run on the EDW
    :params str args: The arguments passed down from main
    :return int: 0 for a successful update of the table. 1 for a failure (note a failure here will cause the sqoop job to fail unless it is caught in a try except)
    '''
    edw_user = keyuser
    jceks = 'jceks://file'+args.jceks

    sqoop_bash = '''
        sqoop eval --libjars '''+libpath+''' \
        -Dhadoop.security.credential.provider.path='''+jceks+''' \
        --username '''+edw_user+''' \
        --password-alias 'sqoop.password' \
        --driver com.teradata.jdbc.TeraDriver \
        --connect jdbc:teradata://'''+edw_hostname+'''/database='''+edw_db+''' \
        --e "'''+edw_stmt+'''"
        '''

    rt = os.system(sqoop_bash)
    return rt 
    
        
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Testing the connection between Hadoop and teradata.')
    parser.add_argument('edwHostName', type=str, help='HostName of EDW')
    parser.add_argument('edwDatabaseName', type=str, help='Database name of EDW')
    parser.add_argument('edwTableName', type=str, help='Table name of EDW')
    parser.add_argument('hiveHostName', type=str, help='HostName of Hive')
    parser.add_argument('hiveDatabaseName', type=str, help='Database name of Hive')
    parser.add_argument('hiveTableName', type=str, help='Table name of Hive') 
    parser.add_argument('--jceks', type=str, help='Standard path to java key store location. Do not set for unsecured access.')
    
    args = parser.parse_args()   
    tdConnectionTest(args)
