# -*- coding: utf-8 -*-
"""
Created on Thu Mar  9 10:31:19 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""
# python >= python2.7

import sys
import argparse
from datetime import datetime, timedelta
from subprocess import check_output
import json
import ast
import calendar
import socket
import warnings
try:
    import jks
except:
    warnings.warn('scheduler.py: No JKS module found. JKS functionality unavailable', ImportWarning)
    have_jks = False
else:
    have_jks = True
import pyodbc
from random import randint
from dsspy import connections as dsc
from dsspy import utilities as dsu
import data_pipeline as dp


def get_used_ports():
    '''
    Return the ports currently in use on the system via netstat 
    
    :return: A tuple of ports in use, the lowest port available and the highest port available
    '''
    
    lowest_port = 1024
    highest_port = 65335
    
    cmd = 'netstat -lat'
    vals = check_output(cmd, shell=True).decode('ascii').split('\n')
    ports = []
    
    bad_val = False

    for val in vals:
        try:
                add = val.split()[-2]
                port = add.split(':')[-1]
                ports.append(int(port))
        except:
                bad_val = True

    ports = sorted(ports)

    return ports, lowest_port, highest_port

    
# supported onfailure/success actions
supported_actions = ['email','quit','continue']
weekday_map = dict(zip(list(calendar.day_name), range(7)))

class SolrError(Exception):
    """Base class for exceptions in solr."""
    pass
    
def run_sql(sql, keystore, keyuser, keypass, isfile = False, parms = None, storepass = 'none'):
    ks = jks.KeyStore.load(keystore, storepass).secret_keys
    biuser = ks[keyuser].key.decode('utf-8')
    bipass = ks[keypass].key.decode('utf-8')
    
    #print(sql)
    #print(parms)

    with pyodbc.connect("DRIVER=DB2;DATABASE=bigsql;HOSTNAME="+str(socket.gethostname()) +";PORT=32051;PROTOCOL=TCPIP;UID="+str(biuser)+";PWD="+str(bipass)+";", autocommit=False,unicode_results=False) as conn:
        cursor = conn.cursor()
        if parms is not None:
            cursor.execute(sql, parms)
        else:
            cursor.execute(sql)
        
    return 0


def increment_run_control_date(args, dt, run_control_date, inc=1):

    new_run_control_date = run_control_date + timedelta(days=inc) # increment RCT by inc days (default =1)
    
    outdict = {'id':'SCHEDULER_RUN_CONTROL_DATE'
    , 'conf':'{"RUN_CONTROL_DATE":"'+new_run_control_date.strftime("%Y-%m-%d")+'", "LOAD_DATE":"'+dt.strftime("%Y-%m-%d")+'"}'}
    
    dsc.write_to_solr(args.solr_metadata_core, outdict, jceks = args.jceks, jceks_pass = args.jceks_pass)
    
    return 0
            

def find_jobs(dt, solr_mcore, args):
    contents = dsc.query_solr(solr_mcore, jceks = args.jceks)
    jobs = []
    
    print('Scanning list of '+str(len(contents['response']['docs']))+' potential jobs.')
    
    for doc in contents['response']['docs']:
        job_id = doc['id']

        try:
            conf = json.loads(doc['conf'][0])['SCHEDULER_CONF']
        except KeyError:
            print('Warning: missing scheduler information for job '+job_id)
            print('Job will be skipped')
            continue
        
        if conf['SCHEDULER_TYPE'].lower() != 'sched':
            print('Job '+job_id+' is handled by a different scheduler. Will not be processed.')
            continue
        
        should_run = False
        
        # unless overriding times, go ahead and check to see if we should run
        
        if not(args.override_sched_times):
            
            try: # enclose in try in case of badly worded run times
                
                runtimes = ast.literal_eval(conf['RUN_TIMES'])
            
                tol = float(conf['TOLERANCE']) # get the tolerance in minutes
            
                for cron_name, times in runtimes.items():
                
                    if len(times) != 5: # Format: Minute - Hour - Day - Weekday - Month
                        print('Warning: Malformed scheduler information for job '+job_id)
                        print(str(cron_name)+': '+str(times))
                        print('This crontab will be skipped')
                        continue
                        
                    runtime_minute = times[0] # Minute
                    if runtime_minute == '*' or 'every' in runtime_minute.lower():
                        runtime_minute = dt.minute
                    else:
                        runtime_minute = int(runtime_minute)
                        
                    runtime_hour = times[1] # Hour
                    if runtime_hour == '*' or 'every' in runtime_hour.lower():
                        runtime_hour = dt.hour
                    else:
                        runtime_hour = int(runtime_hour)
                        
                    runtime_day = times[2] # Day
                    if runtime_day == '*' or 'every' in runtime_day.lower():
                        runtime_day = dt.day
                    else:
                        day_list = times[2].split(',')
                        day_list_int = [int(i.strip()) for i in day_list]
                        runtime_day = min(list((i,abs(i-dt.day)) for i in day_list_int), key = lambda x: x[1])[0] # get nearest day to current day for runtime test
                            
                    
                    correct_weekday = times[3] # the weekday is a yes or no question - does today match the given weekday(s)?
                    if ('every' in correct_weekday.lower() or 'n/a' in correct_weekday.lower()) or correct_weekday == '*':
                        if 'every' in correct_weekday.lower() and dt.weekday() > 4:
                            correct_weekday = False
                        else:
                            correct_weekday = True
                    else:
                        day_list = times[3].split(',')
                        day_list_int = [weekday_map[i.strip()] for i in day_list]
                        if dt.weekday() in day_list_int:
                            correct_weekday = True
                        else:
                            correct_weekday = False
            
                    runtime_month = times[4] # month
                    if runtime_month == '*' or 'every' in runtime_month.lower():
                        runtime_month = dt.month
                    else:
                        month_list = times[4].split(',')
                        month_list_int = [int(i.strip()) for i in month_list]
                        runtime_month = abs(dt.month - min(abs(i-dt.month) for i in month_list_int)) # get nearest day to current day for runtime test            
                    
                    runtime = datetime(dt.year, runtime_month, runtime_day, runtime_hour, runtime_minute) # get the runtime as a proper time
                    diff = abs((runtime - dt).total_seconds())/60.0 # get the difference in minutes
                    
                    should_run = ((diff < tol) and correct_weekday)
                    
                    if should_run:
                        break # if the job matches one cron entry, break before it potentially matches another
                    
            except(ValueError, KeyError):
                print('Malformed run times detected. Job will not be run unless times are overrided.')
                should_run = False # trouble reading times? Assume invalid
            
            
        if should_run or args.override_sched_times:
            if args.override_sched_times:
                print('Overriding scheduler times.')
            else:
                print('Running due to a difference of '+str(diff)+' minutes, inside the tolerance of '+str(tol))
                print('Current run control day = '+str(dt.weekday())+', which matches the selection: '+str(times[3]))
                                
            try:        
                deps = conf['deps']
            except KeyError:
                deps = []
                
            try:
                jobtype = json.loads(doc['conf'][0])['JOB_TYPE']
            except KeyError:
                jobtype = 'acquisition'
                
            if jobtype == 'acquisition':
                jobconf = json.loads(doc['conf'][0])['LOADER_METADATA']
                source = json.loads(doc['conf'][0])['FileEvalutor']['SOURCE']
                srce_sys = jobconf['PARTITIONS']['srce_sys']['value']
                if args.source.lower() != source.lower() and args.source != '*':
                    print('Job '+job_id+' does not match source specified')
                    continue # banned source, move onto next job
                if args.srce_sys.lower() != srce_sys.lower() and args.srce_sys != '*':
                    print('Job '+job_id+' does not match srce_sys specified')
                    continue # banned srce_sys, move onto next job
            elif jobtype == 'bigsql':
                jobconf = {'type':json.loads(doc['conf'][0])['BIGSQL_TYPE'], 'payload':json.loads(doc['conf'][0])['BIGSQL_PAYLOAD']}
            elif jobtype == 'run_control_date_inc':
                try:
                    jobconf = {'inc':int(json.loads(doc['conf'][0])['INCREMENT'])} # if a difference increment is specified, do it
                except Exception:
                    jobconf = {'inc':1} # otherwise increment by 1
            else:
                print('Unsupported job type: '+jobtype+'. Job '+job_id+' will not be scheduled.')
                continue
            
            try:
                onfailure = ast.literal_eval(conf['ONFAILURE']) # interpret onfailure behaviour as a python list of dicts
                onsuccess = ast.literal_eval(conf['ONSUCCESS']) # interpret onsuccess behaviour as a python list of dicts
            except ValueError:
                print('Error determining onfailure/success behaviours from excel for '+job_id)
                onfailure = None
                onsuccess = None
    
            jobs.append({'id':job_id , 'deps':deps, 'onsuccess':onsuccess,'onfailure':onfailure, 'conf':jobconf, 'type':jobtype})
            
            print('Job '+job_id+' scheduled to run.')
                        
        else:
            
            print('Job '+job_id+' will not be run')
            
    return jobs
    
    
# actually run the job
    
def run_job(dt, job, args, run_control_date, test_mode, port):
    
    print('Processing '+job['id'])
    start_time = datetime.utcnow()
    ctime = (start_time.replace(second=0, microsecond=0)).strftime("%Y-%m-%d %H:%M").replace(' ','_') # truncate to minute
    jobname = job['id'] + '_' + ctime
    
    if job['type'] == 'acquisition':

        
        acquire_args = argparse.Namespace(steps='validate,etl,post_validate', jar_path=args.spark, solr_run_control_url=args.solr_metadata_core, 
                                          solr_logging_url=args.solr_logging_core, bigsql_logging_table=args.bigsql_logging_table, 
                                          solr_url=args.solr_metadata_core, search_term=job['id'], jceks=args.jceks, log4j_path = args.log4j_path,
                                          appname = 'SCHEDULER_RUN_CONTROL_DATE', run_control_date = run_control_date.strftime('%Y-%m-%d'), jceks_pass=args.jceks_pass, debug = False)    

        if not(test_mode['on']):
            try:
                outcome = dp.process(acquire_args)
            except Exception as e:
                print('An error has occured: '+str(e))
                outcome = 1
        else:
            outcome = 1
            msg = 'Job run test successful for '+jobname
            print(msg)
            test_mode['file'].write(jobname+'\n')
        
    elif job['type'] == 'bigsql':
        try:
            if job['conf']['type'] == 'command':
                outcome = run_sql(job['conf']['payload'], args.jceks, 'bigsql.user', 'bigsql.password')
            elif job['conf']['type'] == 'file':
                outcome = run_sql(job['conf']['payload'], args.jceks, 'bigsql.user', 'bigsql.password', True)
        except Exception:
            print('Error running BigSQL job '+jobname)
            outcome = 1
        
        
    elif job['type'] == 'run_control_date_inc':
        try:
            outcome = increment_run_control_date(args, dt, run_control_date, job['conf']['inc'])
        except:
            print('MAJOR ERROR!!!     ERROR INCREMENTING JOB CONTROL DATE')
            outcome = 1
        
    else:
        print('Unsupported job type: '+job['type']+'. Skipping job.')
        outcome = 1
    
    if outcome == 0:
        success_ind = True
    else:
        success_ind = False
    
    # post log to solr if needed
    
    # perform on success/failure actions
    try:
        if outcome ==0:
            print(jobname+' successful.')
            actions =  job['onsuccess']
            if actions is not None:
                if len(actions) == 0:
                    return 0
                else:
                    print('Action '+str(actions)+' not implemented yet!')
        else:
            print(job['id']+' failed.')
            actions =  job['onfailure']
            if actions is not None:
                for action in actions:
                    if action != 'None' and action is not None:
                        for key, value in action.items():
                            
                            msg = '\n\nMore details can be found at on solr at '+args.solr_logging_core.split('select')[0]+'select?indent=on&q=job_name%3A%22'+'_'.join(job['id'].split('_')).replace(':','?')\
                            +'%22%20AND%20log_date%3A'+start_time.strftime("%Y-%m-%d")+'\n\n'

                            msg = msg + 'See https://wiki.aib.pri/display/HAD/a.+Recover+from+an+ETL+failure for further instructions \n\n'
                            
                            if key not in supported_actions:
                                print('Warning: unsupported action. Will email.')
                                msg = msg + 'Cause of error: Unsupported action: '+key+'. List of supported actions: '+str(supported_actions)
                                key = 'email'
                            
                            if key == 'email':
                                if value == 'datascience@aib.ie':
                                    value = 'hadoop.supp@aib.ie' # all job emails should go here from now on
                                dsc.sendemails('Error processing data for job '+jobname, 'There has been an error processing '+jobname + '\n\n' + msg,extra_recipients=value, rotafile = args.rotafile)

                            if key == 'continue':
                                break
                            
                            if key == 'quit':
                                return 0
                                break
    except (ValueError, TypeError, KeyError):
        if outcome == 0:
            print('Unexpected error occurred  performing success behaviour. Job complete, but onsuccess behaviour failed for'+jobname)
        else:
            print(jobname+' failed. An error also occured when attempting to perform onfailure actions.')
        print('Please check the format and syntax of the onfailure/onsuccess behaviour.')
        
    if not(success_ind):
        raise Exception(jobname+'has failed.') # raise an exception formally so the scheduler knows an error has occured
        
    return success_ind
    
# read the arguments

if __name__ == '__main__':
        
    parser = argparse.ArgumentParser(description='Scheduler. Run scheduled jobs from a manifest file.')
    parser.add_argument('spark', type=str, help='The path to the spark job')
    parser.add_argument('solr_metadata_core', type=str, help='Solr Metadata URL. Unless ignoring scheduler times, this will be truncated to include all jobs.')
    parser.add_argument('source', type=str, help='Data source (hr/icm/*). Not case sensitive.')
    parser.add_argument('srce_sys', type=str, help='Data source system (an integer).')
    parser.add_argument('solr_logging_core', type=str, help='Solr logging URL.')
    parser.add_argument('jceks', type=str, help='Key store with solr keys.')
    parser.add_argument('bigsql_logging_table', type=str, help='BigSQL logging table. SCHEMA.TABLE')
    parser.add_argument('log4j_path', type=str, help='Full path to log4j properties file')
    parser.add_argument('--test_mode',action="store_true" , help='Boolean. Operate in test mode (run nothing!).')
    parser.add_argument('--jceks_pass', type=str, help='Key store password.')
    parser.add_argument('--rotafile', type=str, help='Location of email rota file.')
    parser.add_argument('--override_sched_times',action="store_true", help='Call with this option to ignored scheduled times and run all return jobs.')
    
    
    
    args = parser.parse_args()
    
    if args.test_mode:
        test_mode = {'on':True, 'file':open('testlog.txt','a')}
    else:
        test_mode = {'on':False}
    
    # get current time. Take daylight savings/timezone into account for scheduling, but not for logs!
    
    dt = datetime.now()
    dtutc = datetime.utcnow()
    
    # get the run control date
    try:
        solr_mcore = args.solr_metadata_core.split('select')[0]+'select?q=id%3ASCHEDULER_RUN_CONTROL_DATE&wt=json&rows=1'
        contents = dsc.query_solr(solr_mcore, jceks = args.jceks)
    except Exception:
        print('Empty solr core found. Will intialise with today\'s date.')
        run_control_date = dt
        outdict = {'id':'SCHEDULER_RUN_CONTROL_DATE'
        , 'conf':'{"RUN_CONTROL_DATE":"'+run_control_date.strftime("%Y-%m-%d")+'", "LOAD_DATE":"'+dt.strftime("%Y-%m-%d")+'"}'}
        
        dsc.write_to_solr(args.solr_metadata_core, outdict, jceks = args.jceks, jceks_pass = args.jceks_pass)
    else:
        run_control_date = json.loads(contents['response']['docs'][0]['conf'][0])['RUN_CONTROL_DATE']
        print('Detected run control date = '+run_control_date)
        run_control_date = datetime.strptime(run_control_date,'%Y-%m-%d')
        
    run_control_date = datetime(run_control_date.year, run_control_date.month, run_control_date.day, dt.hour, dt.minute) # take the current hour and min
    
    # read files, truncating unless told to ignore sched times
    
    if args.override_sched_times:
        solr_mcore = args.solr_metadata_core
    else:
        solr_mcore = args.solr_metadata_core.split('select')[0]+'select?q=*%3A*&wt=json&rows=2147483647'
    print("Reading configuration files from "+solr_mcore)
    
    
    # identify jobs to be run
    
    
    try:
        jobs = find_jobs(dt, solr_mcore, args) # use actual current date/time to determine what should be attempted.
    except (KeyError, SolrError) as e:
        if type(e) == KeyError:
            errmsg = 'Key Error identifying jobs to be run from solr core'
        elif type(e) ==SolrError:
            errmsg = 'Solr Error identifying jobs to be run from solr core'
        else:
            errmsg = 'Unknown Error identifying jobs to be run from solr core: '
        print(errmsg)
        print('Will now quit with exception.')
        raise type(e)
    
    
    print(str(len(jobs))+' job(s) to be run')
    
    bad_jobs = []
    used_ports, lowest_port, highest_port = get_used_ports()
    port = used_ports[0]
    
    try:
        ps = []
        for job in jobs:
            while port in used_ports:
                port = randint(lowest_port, highest_port)
            used_ports.append(port)
            p = dsu.ProcessWithExceptionHandling(target=run_job, args=(dt, job, args, run_control_date, test_mode, port))
            ps.append(p)
            p.start()
            
        for job_num , p in enumerate(ps):
            timeout_limit = 86400
            p.join(timeout_limit) # timeout set to 1 day, just in case 60*60*24 = 86400
            if p.is_alive():
                errmsg = 'Error: job '+jobs[job_num]['id']+' took longer than '+str(timeout_limit)+' to run, exiting with error!'
                ctime = (dt.replace(second=0, microsecond=0)).strftime("%Y-%m-%d %H:%M").replace(' ','_') # truncate to minute
                sys.exit(1)
            if p.exception:
                error, trace = p.exception
                errmsg = 'Error: Job '+jobs[job_num]['id']+' did not complete successfully'
                print('Error = '+str(error)+', trace = '+str(trace))
                bad_jobs.append(jobs[job_num]['id'])
                
    except Exception as e:
        errmsg = 'Unexpected error running jobs.'
        print(errmsg)
        print(e)
        print(type(e))
        sys.exit(1)
    
    if len(bad_jobs) > 0:
        outcome_message = 'Errors occurred in '+str(len(bad_jobs))+' jobs out of a total of '+str(len(jobs))+'.\n\n'
        outcome_message = outcome_message + 'Jobs with errors: \n'
        for job in bad_jobs:
            outcome_message = outcome_message + '\t' + job + '\n'
    else:
        outcome_message = 'Successfully ran all '+str(len(jobs))+' jobs.\n'
    
    good_jobs = [val['id'] for val in jobs]
    good_jobs = list(set(good_jobs).difference(set(bad_jobs)))
    outcome_message = outcome_message + 'Jobs successfully run: \n'
    for job in good_jobs:
        outcome_message = outcome_message + '\t' + job + '\n'
    
    dsc.sendemails('Spark scheduler job report', outcome_message, rotafile = args.rotafile)
    
    if test_mode['on']:
        test_mode['file'].close()
    print('Scheduling complete.')
    
                
                