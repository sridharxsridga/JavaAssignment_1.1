# -*- coding: utf-8 -*-
"""
Created on Fri Jul  7 12:01:26 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

from dsspy import connections as dc
from dsspy import utilities as dsu
from dsspy import logging as dsl
from data_pipeline_lib.utils import get_export_sqoop_metadata, get_count
import argparse
import getpass
import json
import os
import warnings
import subprocess
try:
    import jks
except:
    warnings.warn('No JKS module found. JKS functionality unavailable', ImportWarning)
    have_jks = False
else:
    have_jks = True


def export_sqoop(conf_json, job_id, run_control_date_str, args, num_mappers = 4, storepass = 'none'):
    '''
    Exports the full hive staging table populated with hive_staging.py to Teradata. This checks to see if the Teradata table is empty before running Sqoop. 
    It validates that the record counts are the same on the hive and Teradata sides post sqoop. 

    :param str conf_json: Solr conf json, contains the jobs metadata information
    :param str job_id: Solr id for the job
    :param str run_control_date_str: The current run control date in string format (as apposed to a python datetime object)
    :param str args: The arguments passed down from data_pipeline.py
    :param str num_mappers: The number of mappers (parallel processes) to use on the hadoop side. Defaults to 4
    :param str storepass: the keystore password
    :return int: 0 for a successful sqoop load. 1 for a failure
    '''

    keystore = args.jceks
    jobname = args.job_name
    jceks = 'jceks://file'+args.jceks
    ks = jks.KeyStore.load(keystore, storepass).secret_keys
    td_user = ks['sqoop.user'].key.decode('utf-8')
    

    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)

    metadata = get_export_sqoop_metadata(conf_json, args)[job_id]
    
    # Could check solr to see that last job ran etc., but this sort of analysis should really be done by the scheduler!
    #defining parameters for running sql select - see connections in dsspy for run_sql syntax

    hive_stmt = "SELECT COUNT(*) FROM " + metadata['hive_staging_schema'] + "." + metadata['hive_staging_table'] + ";"
    edw_im_create_stmt = "CREATE TABLE " + metadata['edw_db'] + "." + metadata['edw_table'] + "_IM AS (SELECT * FROM "+metadata['edw_db'] + "." + metadata['edw_table']+") WITH NO DATA NO PRIMARY INDEX;"
    edw_im_count_stmt = "SELECT COUNT(*) FROM " + metadata['edw_db'] + "." + metadata['edw_table'] + "_IM;"
    edw_im_drop_stmt = "DROP TABLE " + metadata['edw_db'] + "." + metadata['edw_table'] + "_IM;" 
    edw_insert_stmt = "INSERT INTO " + metadata['edw_db'] + "." + metadata['edw_table'] + " SELECT * FROM "+ metadata['edw_db'] + "." + metadata['edw_table'] + "_IM;"
    edw_count_stmt = "SELECT COUNT(*) FROM " + metadata['edw_db'] + "." + metadata['edw_table'] + ";"
    edw_hostname = 'ncrdwprod.aib.pri'
    hive_hostname = metadata['hostname']
    libpath="/usr/iop/4.2.5.0-0000/sqoop/lib/teradata-connector-1.5.3.jar" #omega post upgrade

    try:
        edw_pre_count = dc.sqoop_eval(libpath, edw_hostname,'sqoop.user', 'sqoop.password', metadata['edw_db'], edw_count_stmt, keystore = args.jceks)
    except Exception as e:
        logger.error(str(e))
        logger.error('Cannot access Staging table to count')
        result = 1
        return result

    #drop IM table. 
    drop = run_edw_stmts(libpath, edw_hostname, td_user, metadata['edw_db'], edw_im_drop_stmt, args)
    if drop !=0:
        logger.warn('IM Table does not exist')
    else:
        logger.info('IM table dropped')

    #creating IM table. Fail job if error here.
    rt = run_edw_stmts(libpath, edw_hostname, td_user, metadata['edw_db'], edw_im_create_stmt, args)
    if rt !=0:
        logger.error('Sqoop error: '+jobname+'\nError creating IM table')
        result = rt
        return result

    #counting records in hive table
    hive_count = get_count(hive_stmt,hive_hostname,'bigsql.user', 'bigsql.password', keystore = args.jceks)

    #below is the sqoop query defined in terms of the metadata. 

    sqoop_bash = '''
sqoop tdexport -Dteradata.db.output.source.database='''+metadata['hive_staging_schema']+''' \
-Dtdch.input.timestamp.format="yyyy-MM-dd HH:mm:ss" \
-Dhadoop.security.credential.provider.path='''+jceks+''' \
-Dteradata.db.output.method=internal.fastload \
--connect jdbc:teradata://'''+edw_hostname+'''/database='''+metadata['edw_db']+''',CLIENT_CHARSET=ISO8859_1 \
--username '''+td_user+''' \
--password-alias 'sqoop.password' \
--hive-table '''+metadata['hive_staging_table']+''' \
--table '''+metadata['edw_table']+'''_IM \
--num-mappers '''+str(num_mappers)+'''
    '''
    logger.info(sqoop_bash)
    rt = os.system(sqoop_bash) # run the sqoop job
    if rt !=0:
        raise(Exception('Sqoop error: '+jobname))
    #counts the records in the edw IM table. Should match the hive staging table
    edw_im_count = dc.sqoop_eval(libpath, edw_hostname,'sqoop.user', 'sqoop.password', metadata['edw_db'], edw_im_count_stmt, keystore = args.jceks)
    logger.info('Hive record count : ' + str(hive_count))
    logger.info('EDW record count : ' + str(edw_im_count))
    if edw_im_count != hive_count:
        logger.error('Sqoop validation error: ' + jobname + '\nRecord counts do not match')
        result = 1
    else:
        #if counts match, insert from IM to staging. 
        rt = update_records(libpath, edw_hostname, td_user, metadata['edw_db'], metadata['edw_table'], str(edw_im_count), run_control_date_str, args)
        if rt !=0:
            raise(Exception('Error updating record count table'))   
        else:
            logger.info('Record count table updated')
            rt = run_edw_stmts(libpath, edw_hostname, td_user, metadata['edw_db'], edw_insert_stmt, args)
            if rt !=0:
                # revert update table code to go here if required.
                raise(Exception('Insert from IM to Staging Failed'))
            else:
                logger.info('Insert from IM to Staging complete')
                logger.info('Sqoop successful: '+jobname)
        result = rt
    #cleaning down IM table. Should do this whether or not transfer is successful.    
    try: 
        run_edw_stmts(libpath, edw_hostname, td_user, metadata['edw_db'], edw_im_drop_stmt, args)
        logger.info('IM table dropped')
    except Exception as e:
        logger.warning(str(e))
        logger.warning('IM Table not dropped')    
    
    return result

def update_records(libpath, edw_hostname, keyuser, edw_db, edw_table, record_count, run_control_date_str, args):
    '''
    If sqoop job is successful it populates the record count table in Teradata with the number of transfered recored and the corresponding run control date

    :params str libpath: The path to the Teradata connector jar, currently passed in from sqooper.py. 
    :params str edw_hostname: The url for the Teradata box, i.e. BCP vs Prod
    :params str keyuser: The username to use when running the update statement. Currently it should be passed down from sqooper.py
    :params str edw_db: The database to connect to on Teradata
    :params str edw_table: The table name to search for in the records count table order to update the correct row. Should be the same table that sqoop had just populated
    :params str record_count: The number of records just written by sqoop
    :params str run_control_date_str: The current run control date in string format (as apposed to a python datetime object)
    :params str args: The arguments passed down from data_pipeline.py
    :return int: 0 for a successful update of the table. 1 for a failure (note a failure here will cause the sqoop job to fail)
    '''
    edw_user = keyuser 

    jceks = 'jceks://file'+args.jceks

    run_control_date_str = "'"+run_control_date_str+"'" 
    edw_table_str = "'"+edw_table+"'"
    '''
    following sqoop query utilises the sqoop eval function to run an update query on our records table. 
    This is a workaround as the jdbc connector for teradata was causing issues with JVMs crashing when we tried to call run_sql from dsspy
    '''
    sqoop_update = '''
sqoop eval --libjars '''+libpath+''' \
-Dhadoop.security.credential.provider.path='''+jceks+''' \
--username '''+edw_user+''' \
--password-alias 'sqoop.password' \
--driver com.teradata.jdbc.TeraDriver \
--connect jdbc:teradata://'''+edw_hostname+'''/database='''+edw_db+''' \
--e "UPDATE SQOOP_JOB_RECORDS SET RECORD_COUNT = '''+record_count+''',RUN_CONTROL_DATE ='''+run_control_date_str+''' WHERE TABLE_NAME = '''+edw_table_str+''';"'''

    rt = os.system(sqoop_update)
    if rt !=0:
        raise(Exception('Sqoop record count table update error'))
    return rt

def run_edw_stmts(libpath, edw_hostname, keyuser, edw_db, edw_stmt, args):
    '''
    Designed to run deletes of the IM tables and then inserts into main tables

    :params str libpath: The path to the Teradata connector jar, currently passed in from sqooper.py. 
    :params str edw_hostname: The url for the Teradata box, i.e. BCP vs Prod
    :params str keyuser: The username to use when running the update statement. Currently it should be passed down from sqooper.py
    :params str edw_db: The database to connect to on Teradata
    :params str edw_stmt: The statement to run on the EDW
    :params str args: The arguments passed down from data_pipeline.py
    :return int: 0 for a successful update of the table. 1 for a failure (note a failure here will cause the sqoop job to fail unless it is caught in a try except)
    '''
    edw_user = keyuser
    jceks = 'jceks://file'+args.jceks

    sqoop_bash = '''
sqoop eval --libjars '''+libpath+''' \
-Dhadoop.security.credential.provider.path='''+jceks+''' \
--username '''+edw_user+''' \
--password-alias 'sqoop.password' \
--driver com.teradata.jdbc.TeraDriver \
--connect jdbc:teradata://'''+edw_hostname+'''/database='''+edw_db+''' \
--e "'''+edw_stmt+'''"
'''

    rt = os.system(sqoop_bash)
    return rt


def import_sqoop(conf_json, job_id, previous_rcd, current_rcd, args, num_mappers = 4):
    '''
    This function is not yet complete, but will have similar arguments to export sqoop

    '''

    td_user = input('Please enter the Teradata user: ')
    td_pass = getpass.getpass('Please enter the corresponding Teradata password: ')

    keystore = args.jceks
    jobname = args.job_name

    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)

    #stub for parsing run control date formats
    previous_rcd_str = parse(previous_rcd)
    current_rcd_str = parse(current_rcd)

    #organising metadata parameters
    metadata = utils.get_import_sqoop_metadata(conf_json, args)[job_id]

    #lands to a text file within a folder for the current run date. External table built over this.
    target_file_location = metadata['target_file_location'] + '/run_date='+current_rcd_str
    os.makedirs(target_file_location, exist_ok=True) # create landing dir if not exists. 
    where_clause = "PERIOD_DTE > '" + previous_rcd_str + "' AND LIFECYCLE_STATUS_CODE = 'SETTLED'"

    hive_text_stmt = "SELECT COUNT(*) FROM " + metadata['hive_staging_schema'] + "." + metadata['hive_staging_table'] + " WHERE "+where_clause+";"
    hive_pq_stmt = "SELECT COUNT(*) FROM " + metadata['hive_pq_schema'] + "." + metadata['hive_pq_table'] + " WHERE "+where_clause+";"
    edw_stmt = "SELECT COUNT(*) FROM " + metadata['edw_db'] + "." + metadata['edw_table'] + " WHERE "+where_clause+";"
    edw_hostname = 'Teradata'
    update_partition_stmt = "ALTER TABLE " + metadata['hive_staging_schema'] + "." + metadata['hive_staging_table'] + " ADD PARTITION(run_date='"+current_rcd_str+"');"

    os.environ['sqoop_td_pass'] = td_pass # use an enviroment variable to pass the password, keeping it out of logs

    edw_count = utils.get_count(edw_stmt,edw_hostname,td_user,td_pass) # need to put the edw passwords into keystore

    if edw_count == 0:
        raise(Exception('Sqoop error: '+jobname +'\nNo records since last run date'))
        result = 1


    sqoop_bash = '''
sqoop tdimport -Dhadoop.security.credential.provider.path=jceks://hdfs/user/sqoop/sqooptest1.jceks \
-Dteradata.db.input.num.partitions.in.staging=1 \ 
--connect jdbc:teradata://ncrdwprod.aib.pri/database='''+metadata['edw_db']+''' \
--username '''+td_user+''' \
--password $sqoop_td_pass \
--table '''+metadata['edw_table']+''' \
--where '''+where_clause+'''\
--split-by '''+metadata['split_col']+''' \
--target-dir '''+target_file_location+''' \
--input-fields-terminated-by '''+metadata['textfile_delimiter']+'''\
--num-mappers '''+str(num_mappers)+'''
    '''
    
    rt = os.system(sqoop_bash) # run the sqoop job
    os.environ['sqoop_td_pass'] = ''
    if rt !=0:
        raise(Exception('Sqoop error: '+jobname))
    dsc.run_sql(update_partition_stmt, hive_hostname, 'bigsql.user', 'bigsql.password', keystore = args.jceks) 
    hive_text_count = get_count(hive_stmt,hive_hostname,'bigsql.user', 'bigsql.password', keystore = args.jceks)
    logger.info('EDW record count : ' + str(edw_count))
    logger.info('Hive text file record count : ' + str(hive_text_count))
    if hive_text_count != edw_count:
        raise(Exception('Sqoop error:' + jobname + '\nRecord counts do not match.'))
        result = 1
    else:
        logger.info('Sqoop successful: '+jobname)
        result = rt    
        
    return result


