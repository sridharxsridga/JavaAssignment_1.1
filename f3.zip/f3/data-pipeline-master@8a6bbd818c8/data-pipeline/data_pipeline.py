# -*- coding: utf-8 -*-
"""
Created on Mon Sep 11 14:33:05 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

import data_pipeline_lib.validation as validation
import data_pipeline_lib.acquisition as acquisition
import data_pipeline_lib.sync as sync
import data_pipeline_lib.utils as utils
import data_pipeline_lib.batch_control as batch_control
import data_pipeline_lib.hive_staging as hive_staging
import data_pipeline_lib.sqooper as sqooper
from dsspy import connections as dsc
from dsspy import logging as dsl
import argparse
import json
from datetime import datetime
import os

valid_steps = ['validate','etl', 'export_sqoop', 'sql', 'post_validate', 'update_run_control_date', 'hive_staging']

# return true if a failure occured in the last job for this metatdata entry, false if everything is ok
def check_for_failure(job_name, solr_logging_core, appname, step, jceks):
    '''
    Check to see if the previous job with the same ID ended in failure. Return true if so.
    
    :param str job_name: Solr id for job
    :param str solr_logging_core: URL to solr logging core
    :param str jceks: jceks keystore path
    :return: True if the previous job failed, false otherwise.
    '''
    # create the search term that will look for the jobname and appname and step
    searchTerm = job_name.replace('(', '*').replace(')', '*') + '_' + appname + '_*' + step + '*'
    solr_url = solr_logging_core.split('select')[0]+'select?q=id%3A'+searchTerm+'&sort=log_time+desc&wt=json&rows=1'
    contents = dsc.query_solr(solr_url, jceks = jceks)
    
    if len(contents['response']['docs']) == 0:
        return False # if there is no log, we can continue
        
    outcome = contents['response']['docs'][0]['success_ind']
    return not(outcome) # need to reverse this
        
def process(args):
    '''
    Actually run the requested job
    
    :param namespace args: Arguments from command line (see below).
    :param str steps: The steps to take. Comma separated list of valid steps; 'validate','etl', 'export_sqoop', 'sql', 'post_validate', 'update_run_control_date', 'hive_staging'
    :param str solr_url: Solr URL.
    :param str search_term: Search term.
    :param str solr_run_control_url: Solr run control URL.
    :param str solr_logging_url: Solr logging URL.
    :param str bigsql_logging_table: BigSQL logging table. SCHEMA.TABLE
    :param str appname: Name of TWS application. Will be appended to Job ID to form name
    :param str --jar_path: Path to spark JAR directory. Should contain versioned folders, plus a default folder.
    :param str --log4j_path: Path to log4j properties file.
    :param str --jceks: Standard path to java key store location. Do not set for unsecured access.
    :param str --db2_conn_str: BigSQL connection string (for logging, batch control)
    :param str --run_control_date: If specified, take run control date in format yyyy-mm-dd
    :param str --prev_run_control_date: If specified, take  previous run control date in format yyyy-mm-dd
    :param str --run_control_table: BigSQL run control table. SCHEMA.TABLE.
    :param str --srce_inst: SRCE_INST to use if splitting hive raw zone tables to different divisisons for staging. e.g. AD Services
    :param boolean --debug: If specified, output additional information to log.
    :param boolean --manual: Running in manual mode. Will not fail due a previous failed job.
    :return: 0 for a success, 1 for an error. Other return codes may be step specific.
    '''
    
    steps = args.steps.split(',')
    for step in steps:
        if step not in valid_steps:
            raise Exception(args.steps+' is not a valid step.')


    #solr_url = 'http://rhhdpomt8.mid.aib.pri:8983/solr/Production-Job-Configuration/select?q=hr&wt=json&indent=true'
    if 'select' not in args.solr_url or 'select' not in args.solr_run_control_url:
        print('Please include the select handler in the solr url')
        raise(argparse.ArgumentError)
        
    # get run control dates
    
    run_control_date, run_control_date_str, prev_run_control_date, prev_run_control_date_str = batch_control.get_run_control_date(args)
    
    # get metadata for job

    if '*' not in args.search_term:
        solr_url = args.solr_url.split('select')[0]+'select?q=id%3A"'+args.search_term+'"&wt=json'
    else:
        solr_url = args.solr_url.split('select')[0]+'select?q=id%3A'+args.search_term+'&wt=json' # if a wildcard is passed, don't quote the search
    contents = dsc.query_solr(solr_url, jceks = args.jceks)
    
    docs = []
    confs = []
    for doc in contents['response']['docs']:
        docs.append(doc['id'])
        confs.append(doc['conf'])
    
    if len(docs) != 1:
        raise(Exception('Non unity number of jobs found to match '+solr_url+'. Found '+str(len(docs))+' jobs.'))
    else:
        job_name = docs[0]
        conf = json.loads(confs[0][0])
                
    # Generate the job id: Should look like Jobname_TWSAPPNAME_STEPS:etl_RCD:20170901_RUNTIME:20170901
    
    dt = datetime.now()
    dt = dt.replace(second=0, microsecond=0) # truncate to minute
    ctime = dt.strftime("%Y-%m-%d %H:%M").replace(' ','_')
    job_id = job_name + '_' + args.appname + '_STEPS:' + args.steps +  '_RCD:' + run_control_date_str + '_RUNTIME:' + ctime
    args.job_name = job_id
        
    # find location of the logfile
    if 'LOG_FILE' not in conf:
        log_file = '/' + conf['LOADER_METADATA']['IN_FILE_LOCATION'].split('/')[1] + '/_logs/' + conf['LOADER_METADATA']['TARGET_TABLE'].split('.')[1]
        log_file = conf['FileEvalutor']['FS_PREFIX'] + log_file + '/data_pipeline_log.txt'
    else:
        log_file = conf['LOG_FILE']
        
    args.log_file = log_file
    
    # if location does not exist yet, create it
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    
    # start logger
    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)
    logger.info(utils.start_of_log_text)
    
    # check to see if the last job failed
    if check_for_failure(job_name, args.solr_logging_url, args.appname, args.steps, args.jceks) and not(args.manual):
        error = 'Error: Previous failure detected in '+job_name+'. This job will not run. Fix by running manually with --manual parameter.'
        logger.error(error)
        utils.post_log(args, job_id, job_name, conf, False, dt, datetime.now(), args.solr_logging_url, run_control_date, run_control_date, minimal = False)
        raise Exception(error)
    
    
    # run through steps
    
    for step in steps:
        
        logger.info('Starting step: '+step)
        
        try:
        
            if step == 'validate':
                nfiles = validation.validate(conf, run_control_date, args)
                result = 0
                logger.info('Validation complete: '+str(nfiles)+' valid files found.')
                
            elif step == 'etl':
                ret_code, log = acquisition.acquire(conf, run_control_date, job_id, args)
                if ret_code != 0:
                    raise(Exception('Error attempting to acquire data.'))
                else:
                    result = 0
                    sync.sync(conf)
                    
            elif step == 'export_sqoop':
                result = sqooper.export_sqoop(conf, job_id, run_control_date_str, args)
                
            elif step == 'sql':
                conn_str = conf['CONNECTION_STRING']
                if conf['SQL_TYPE'] == 'command':
                    sql_cmd = conf['SQL_PAYLOAD']
                    logger.info('Running command '+sql_cmd)
                else:
                    with open(conf['SQL_PAYLOAD'], 'r') as f:
                        sql_cmd = '\n'.join(f.readlines())
                    logger.info('Running command from '+conf['SQL_PAYLOAD'])
                
                result = dsc.run_sql(sql_cmd, '', 'bigsql.user', 'bigsql.password', conn_str = conn_str, keystore = args.jceks, getdata = False)

            elif step == 'post_validate':
                result = validation.post_validate(conf, run_control_date, args.jceks, args)

            elif step == 'hive_staging':
                result = hive_staging.hive_staging_insert(conf, prev_run_control_date_str, run_control_date_str, job_id, args)
                
            elif step == 'update_run_control_date':
                result = batch_control.set_run_control_date(args)
            
            else:
                raise Exception('Error, step:'+step+' has not been implemented')

            
        except Exception as e:
            result = 1
            log = 'Error attemping step '+step+':\n'+str(e)
            exc_info = (type(e), e, e.__traceback__)
            logger.error(log, exc_info = exc_info)
            utils.post_log(args, job_id, job_name, conf, False, dt, datetime.now(), args.solr_logging_url, run_control_date, run_control_date, minimal = False)
            raise
        else:
            logger.info('Step '+step+' complete')

    
    logger.info('##--## Ending Acqusition Pipeline')
    success = False if result == 1 else True
    utils.post_log(args, job_id, job_name, conf, success, dt, datetime.now(), args.solr_logging_url, run_control_date, run_control_date, minimal = False)

            
    return result
    
    
if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(description='Validate and acquire data using spark application.')
    parser.add_argument('steps', type=str, help='The steps to take. Comma separated list of: '+','.join(valid_steps))
    parser.add_argument('solr_url', type=str, help='Solr URL.')
    parser.add_argument('search_term', type=str, help='Search term.')
    parser.add_argument('solr_run_control_url', type=str, help='Solr run control URL.')
    parser.add_argument('solr_logging_url', type=str, help='Solr logging URL.')
    parser.add_argument('bigsql_logging_table', type=str, help='BigSQL logging table. SCHEMA.TABLE')
    parser.add_argument('appname', type=str, help='Name of TWS application. Will be appended to Job ID to form name')
    parser.add_argument('--jar_path', type=str, help='Path to spark JAR directory. Should contain versioned folders, plus a default folder.')
    parser.add_argument('--log4j_path', type=str, help='Path to log4j properties file.')
    parser.add_argument('--jceks', type=str, help='Standard path to java key store location. Do not set for unsecured access.')
    parser.add_argument('--db2_conn_str', type=str, help='BigSQL connection string (for logging, batch control)')
    parser.add_argument('--run_control_date', type=str, help='If specified, take run control date in format yyyy-mm-dd')
    parser.add_argument('--prev_run_control_date', type=str, help='If specified, take  previous run control date in format yyyy-mm-dd')
    parser.add_argument('--run_control_table', type=str, help='BigSQL run control table. SCHEMA.TABLE.')
    parser.add_argument('--srce_inst', type=str, help='SRCE_INST to use if splitting hive raw zone tables to different divisisons for staging. e.g. AD Services')
    parser.add_argument('--debug',action="store_true", help='If specified, output additional information to log.')
    parser.add_argument('--manual',action="store_true", help='Running in manual mode. Will not fail due a previous failed job.')



    args = parser.parse_args()
    
    ret = process(args)