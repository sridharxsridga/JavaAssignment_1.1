sqooper module
==============

.. automodule:: sqooper
    :members:
    :undoc-members:
    :show-inheritance:
