Running the Data Pipeline
===============


The data pipeline is modular in design and can run a number of different steps, including executing the Spark ETL app, validating files, sqooping to Teradata and running BigSQL commands. All steps executed through the data pipeline are logged to solr, BigSQL and the logging directories on Hadoop following the standard AIB logging patterns. The data pipeline can be run as follows

Executing the data pipeline
------------------

The following command can be used to execute the data pipeline:
::
	python3 data_pipeline.py comma_separated_steps solr_metadata_core solr_id solr_run_control_url solr_logging_url bigsql_logging_table appname --optional_args

A specific example is given below:
::
	python3 data_pipeline.py validate,etl "http://rhhdpomt8.mid.aib.pri:8983/solr/Test-Job-Configuration/select?q=id%3ACALL_LCM*&rows=145&wt=json&indent=true" myid "http://rhhdpomt8.mid.aib.pri:8983/solr/Test-Job-Configuration/select?q=id%3ACALL_LCM*&rows=145&wt=json&indent=true" "http://rhhdpomt8.mid.aib.pri:8983/solr/BatchLogs_Test/select?q=*" HDCWD00S.HADOOP_ETL_BATCH_LOGS_D2 SCHEDULER_RUN_CONTROL_DATE --jar_path=/home/test_data_batch/Pipeline_Deployment/data-pipeline/JAR --log4j_path=/home/test_data_batch/Pipeline_Deployment/data-pipeline/logs.properties --jceks=/bigpfs/user/test_data_batch/bigdata.jceks --debug --run_control_date=2017-11-09 --prev_run_control_date=2017-11-09 --manual


See the following list of :mod:`~data_pipeline` for a list of supported step types and their arguments.

