.. Data Pipeline documentation master file, created by
   sphinx-quickstart.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Data Pipeline documentation.
==============================================

.. image:: images/data_pipeline.png

Data acquisition is the process of moving data in a valid format all the way from the landing directory into the appropriate tier one table. This process involves inspecting the landed file and comparing it to the specifications outlined in the Business Relational Document (BRD), performing any transformations required, moving the data to a hive table and updating BigSQL so that it's aware of the new data. Most of the work is done by a spark program which can validate, transform and load the data into hive (documented separately), however additional software is needed to deploy, run and schedule the process. This software is described in this document.

Running the Data Pipeline
===============


The data pipeline is modular in design and can run a number of different steps, including executing the Spark ETL app, validating files, sqooping to Teradata and running BigSQL commands. All steps executed through the data pipeline are logged to solr, BigSQL and the logging directories on Hadoop following the standard AIB logging patterns.

A standard execution
------------------
A standard use of the pipeline is to run it with a single step via TWS. TWS calls a short script on the VM, which SSHs to the cluster and executes the pipeline with a single step (see below). Typically this is done for each step in the full pipeline so you have something like: TWS executes a validate step, TWS executes an etl step, TWS executes a post-validation step, TWS executes an increment run control step.

Executing the data pipeline
------------------

The following command can be used to execute the data pipeline:
::
	python3 data_pipeline.py comma_separated_steps solr_metadata_core solr_id solr_run_control_url solr_logging_url bigsql_logging_table appname --optional_args

A specific example is given below:
::
	python3 data_pipeline.py etl "http://rhhdpomt8.mid.aib.pri:8983/solr/Test-Job-Configuration/select?q=id%3ACALL_LCM*&rows=145&wt=json&indent=true" myid "http://rhhdpomt8.mid.aib.pri:8983/solr/Test_Batch_Run_Control/select?q=id%3ACALL_LCM*&rows=145&wt=json&indent=true" "http://rhhdpomt8.mid.aib.pri:8983/solr/BatchLogs_Test/select?q=*" HDCWD00S.HADOOP_ETL_BATCH_LOGS_D2 DHAEWADSERV --jar_path=/home/test_data_batch/Pipeline_Deployment/data-pipeline/JAR --log4j_path=/home/test_data_batch/Pipeline_Deployment/data-pipeline/logs.properties --jceks=/bigpfs/user/test_data_batch/bigdata.jceks --debug --run_control_date=2017-11-09 --prev_run_control_date=2017-11-09 --manual


See the following list of :mod:`~data_pipeline` for a list of supported step types and their arguments.

.. include data-pipeline

.. toctree::
   :maxdepth: 2




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
