"""
Utility to create an archive folder for empty files, move them there and to move their respective touch file in to a separate directory

@Author: Killian Watchorn
"""

import os
import argparse
import re
from collections import defaultdict

parser = argparse.ArgumentParser(description = 'Move empty files for Historic loads.')
parser.add_argument('dir_name', type = str, help = 'The directory path to the files.')
parser.add_argument('archive_dir_name', type = str, help = 'The directory path to the archive directory.')

args = parser.parse_args()

empty_files = []
success_files = []
filedate = []
folder_name = []
folder_dir = []

success_dir = os.path.join(args.archive_dir_name+"/SUCCESS_DELIVERY")

for root, dirs, files in os.walk(args.dir_name):
	for file in files:
		folder_name = []
		folder_dir = []
		filename = os.path.join(root, file)
		try:
			#Get all files that have filesize of 0 and do not contain 'SUCCESS_' in the name
			if os.path.getsize(filename) == 0 and 'SUCCESS_' not in filename:
				empty_files.append(file)
					#Create second list of their respective SUCCESS files by prepending 'SUCCESS_' to the filename
				success_files.append('SUCCESS_'+file)
					#Join all list elements from empty_files into one string
				str_empty_files=' '.join(empty_files)
					#Extract all instances from string that match desired pattern
				filedate = re.findall("([0-9]{8})", str_empty_files)
					#Generate archive folder name for each empty log file and place in list
			for i in filedate:
				folder_name.append('period_dte='+i[:4]+'-'+i[4:6]+'-'+i[6:])
		except Exception as e:
			print(str(e))
			continue

#Iterate through each the three generated lists, creating the new archive folder
#Move the respective empty file into the newly created archive folder
#Move the respective success file into the SUCCESS_DELIVERY folder.
for x,y,z in zip(empty_files, success_files, folder_name):
	newdir=os.path.join(args.archive_dir_name+'/',z)
	os.makedirs(newdir, exist_ok=True)
	print("Creating Directory: ",newdir,"\n...")
	print("Moving empty file: ",x,"\n...")
	os.rename(os.path.join(args.dir_name+'/',x),os.path.join(args.archive_dir_name+'/',z+'/',x))
	print("Moving SUCCESS file: ",y,"\n...")
	os.rename(os.path.join(args.dir_name+'/',y),os.path.join(success_dir+'/',y))
	print("\n")