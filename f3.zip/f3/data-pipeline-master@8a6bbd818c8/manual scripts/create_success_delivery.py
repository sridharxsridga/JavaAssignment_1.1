"""
Utility to create Success files for every csv, txt, and xlsx 
@Author Graham Murphy
"""

import os
import argparse

parser = argparse.ArgumentParser(description = 'Creates Success files')
parser.add_argument('dir_name', type = str, help = 'The directory path to the files')
parser.add_argument('--file_ext', type =str, default = ('.csv','.txt', '.xlsx'), help = 'The extension(s) of the files landing, default .csv,.txt, and .xlsx. Can only specify one additional extention at a time outside of the defaults')

args = parser.parse_args()

def touch(path):
    with open(path, 'a'):
        os.utime(path, None)

for file in os.listdir(args.dir_name):
    if not file.lower().startswith("success"):
        if file.lower().endswith(args.file_ext):
            output = os.path.join(args.dir_name,"SUCCESS_"+file )
            touch(output) 