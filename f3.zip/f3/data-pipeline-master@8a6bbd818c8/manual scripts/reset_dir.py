"""
Utility to reset folder at original status
@Author Alessandro Marrella
"""

import os
import argparse

parser = argparse.ArgumentParser(description='Move files back from archive, clear db, remove filtered')
parser.add_argument('prefix', type=str, help='Prefix of the directory')

args = parser.parse_args()

dirs = [dir for dir in os.listdir(".") if os.path.isdir(dir) and args.prefix in dir]

intervals = ["WEEKLY","DAILY","HOURLY","MONTHLY","ADJUSTMENT","INTRADAY","QUARTERLY","YEARLY"]
with open("reset.sh","w") as f:
    for d in dirs:
        for i in intervals:
            f.write("mv /bigpfs/data/"+d+"/"+i+"/ARCHIVE/period_dte*/* /bigpfs/data/"+d+"/"+i+"/IN/ \n")
            f.write("mv /bigpfs/data/"+d+"/"+i+"/REJECT/* /bigpfs/data/"+d+"/"+i+"/IN/ \n")
            f.write("mv /bigpfs/data/"+d+"/"+i+"/ARCHIVE/SUCCESS_DELIVERY/* /bigpfs/data/"+d+"/"+i+"/IN/ \n")
            f.write("rm -r /bigpfs/data/"+d+"/"+i+"/FILTERED/* \n")
        f.write("rm -r /bigpfs/apps/hive/warehouse/hdcwd00p.db/"+d.lower()+"/* \n")
    

