# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 17:02:06 2017

@author: Colm Coughlan. Data Science and Solutions. 40631

This module contains code for running on remote server via SSH
"""

from utilities import parse_args
import glob
try:
    import pty
except:
    print('WARNING: No pty module found. pty functionality unavailable')
from subprocess import Popen, PIPE
import os

class simple_ssh():
    '''
    Simple SSH client to allow pseudo-manual entry of secure password via prompt without keys
    '''
    def __init__(self, client='ssh', host = '', user='', password='', execute=''):
        '''
        simple_ssh has two modes: ssh and rsync
      
        :param str client: ssh or rsync. Specify host, user and password in execute string for rsync
        :param str host: Hostname of target VM
        :param str user: Login user (if in ssh mode)
        :param str password: Login password (if in ssh mode)
        :param str execute: Command to execute
        :return: Return code of procedure
        '''
        self.execval = execute
        self.host = host
        self.user = user
        self.client = client
        self.password = bytes(password)
        self.askpass = True
        self.ret = self.run()

    def run(self):
        '''
        Run command - SSH, SCP and RSYNC are supported.
        Print output to stdout in case of SSH
        Check for error by reading last few lines of output
        Warning: Currently hangs on authentication failure
        '''
        if self.client == 'ssh':
            command = [
                    '/usr/bin/ssh',
                    self.user+'@'+self.host,
                    '-o', 'NumberOfPasswordPrompts=1',
                    self.execval
            ]
        elif  self.client == 'rsync':
            command = [
                    '/usr/bin/rsync',
                    '-avz',
                    '-e ssh',
            ] + self.execval.split()
        elif  self.client == 'scp':
            command = [
                    '/usr/bin/scp',
                    '-r'
            ] + self.execval.split()
        else:
            raise(Exception('Unsupported client'))

        # PID = 0 for child, and the PID of the child for the parent
        pid, child_fd = pty.fork()

        if not pid: # Child process
            # Replace child process with our SSH process
            os.execv(command[0], command)

        ## if we havn't setup pub-key authentication
        ## we can loop for a password promt and "insert" the password.
        while self.askpass:
            try:
                output = os.read(child_fd, 1024).strip()
            except:
                raise(Exception('Error connecting to server.'))
            lower = output.lower()
            # Write the password
            if b'password:' in lower:
                os.write(child_fd, self.password + b'\n')
                break
            elif b'are you sure you want to continue connecting' in lower:
                # Adding key to known_hosts
                os.write(child_fd, b'yes\n')
            else:
                print(output)
                

        log = '' # read the contents of the buffer into a string
        with os.fdopen(child_fd) as bstr:
            output = bstr.read()
            if self.client == 'ssh':
                log = log + output
            
        os.waitpid(pid, 0) # let the child process finish
        
        print(log) # print all messages
        
        last_logs = ' '.join(log.split('\n')[-5:-1]).lower() # check for error at end of messages
        if ('error' in last_logs or 'exception' in last_logs) or 'errno' in last_logs:
            ret = 1
        else:
            ret = 0
            
        return ret

def scp(step, config, main_args):
    '''
    scp from local node to remote server
  
    :param str type: scp
    :param str src: the source file/directory to copy. supports wildcards and multiple comma separated entries
    :param str dest: where to put it on the target
    :param str target: remote server name
    :param str user: remote user login
    :return: Return code of procedure
    '''
    #get arguments
    
    creds = parse_args(config.get('control', 'creds').replace(' ',''), main_args)
    source = parse_args(config.get(step, 'src').replace(' ',''), main_args)
    dest = parse_args(config.get(step, 'dest').replace(' ',''), main_args)
    target = parse_args(config.get(step, 'target').replace(' ',''), main_args)
    user = parse_args(config.get(step, 'user').replace(' ',''), main_args)
    try:
        mode = parse_args(config.get(step, 'mode').replace(' ',''), main_args)
    except:
        mode = 'put'
        
    if mode not in ['put','get']:
        print('Unsupported SCP mode')
        raise(Exception)
    
    if mode == 'put':
        # now support globbing!
        # (could do this by using shell = true in subprocess, but that's not great practice)
        if '*' in source:
            files = glob.glob(source)
            source = ' '.join(files)
            
        # now support multiple files!
        if ',' in source:
            files = source.split(',')
            source = ' '.join(files)
    
        #cmd_line = 'scp -r -o StrictHostKeyChecking=no -i '+creds+' '+source+' '+user+'@'+target+':'+dest
        cmd_line = 'scp -r -i '+creds+' '+source+' '+user+'@'+target+':'+dest
    else:
        cmd_line = 'scp -r -i '+creds+' '+user+'@'+target+':'+source+' '+dest
    print(cmd_line)  
    
    proc = Popen(cmd_line.split(), stdout=PIPE, stderr=PIPE)  

    comms = proc.communicate() # note this waits for completion
    log = comms[0].decode('ascii') + comms[1].decode('ascii')
    print(log)
    
    return(proc.returncode)
    
# rsync from local node to remote note
# note: not fully tested yet!
    
def rsync(step, config, main_args):
    '''
    rsync from local node to remote server

    :param str type: scp
    :param str src: the source file/directory to copy
    :param str dest: where to put it on the target
    :param str target: remote server name
    :param str user: remote user login
    :return: Return code of procedure
    '''
    # get arguments

    creds = parse_args(config.get('control', 'creds').replace(' ',''), main_args)
    source = parse_args(config.get(step, 'src').replace(' ',''), main_args)
    dest = parse_args(config.get(step, 'dest').replace(' ',''), main_args)
    target = parse_args(config.get(step, 'target').replace(' ',''), main_args)
    user = parse_args(config.get(step, 'user').replace(' ',''), main_args)

    cmd_line = "rsync -avr -e 'ssh -i "+creds+"' --exclude={*.git*} "+source+" "+user+"@"+target+":"+dest
    print(cmd_line)
    
    # run
        
    proc = Popen(["rsync","-avr","-e",'ssh -i '+creds,"--exclude={*.git*}",source,user+"@"+target+":"+dest], stdout=PIPE, stderr=PIPE)

    comms = proc.communicate() # note this waits for completion
    
    log = comms[0].decode('ascii') + comms[1].decode('ascii')
    print(log)
    
    return(proc.returncode)
    
# execute sql files on remote server
# searches path to find sql files matching "files"
    
        
def remote_sql(step, config, main_args):
    '''
    Execute SQL on remote machine via jsqsh

    :param str type: remote_sql
    :param str target: target server
    :param str user: user to log in as
    :param str path: path to the the script
    :param str jsqsh_conn: jsqsh connection
    :return: Return code of procedure
    '''
    #get arguments
    
    creds = parse_args(config.get('control', 'creds').replace(' ',''), main_args)
    target = parse_args(config.get(step, 'target').replace(' ',''), main_args)
    path = parse_args(config.get(step, 'path').replace(' ',''), main_args)
    user = parse_args(config.get(step, 'user').replace(' ',''), main_args)
    jsqsh_conn = parse_args(config.get(step, 'jsqsh_conn').replace(' ',''), main_args)
    

    ssh_cmd = '''<<-\'ENDSSH\' eval $\'
    set -e
    echo "Creating Tables"
    for FileName in $(find '''+path+''');
    do
        echo "\\\eval ""$FileName" | jsqsh -vexit_on=true '''+jsqsh_conn+'''
    done
\'
ENDSSH'''

    print(ssh_cmd)
    proc = Popen(['ssh','-i',creds,user+'@'+target,ssh_cmd], stdout=PIPE, stderr=PIPE)

    comms = proc.communicate() # note this waits for completion
    log = comms[0].decode('ascii') + comms[1].decode('ascii')
    print(log)
    
    return(proc.returncode)
    
# execute something on the remote server
# supports execution of bash scripts as well as standard shell commands
# might be a possible security issue here, as you could potentially run anything
# have a safeguard for running rm -rf *, accidently or otherwise
    
    
def remote_exec(step, config, main_args):  
    '''
    Execute commands on a remote server    
    
    :param str type: remote_exec
    :param str target: target server
    :param str user: user to log in as
    :param str file: file to execute (exec_type = bash only). Supports wildcards.
    :param str cmd: command to execute (exec_type = cmd only)
    :param str args: any arguments, comma separated
    :param str exec_type: bash, python, python3, cmd
    :return: Return code of procedure
    '''
    supported_ops = ['bash','python','python3','cmd']
    # read in parameters
    
    creds = parse_args(config.get('control', 'creds').replace(' ',''), main_args)
    target = parse_args(config.get(step, 'target').replace(' ',''), main_args)
    user = parse_args(config.get(step, 'user').replace(' ',''), main_args)
    args = config.get(step, 'args').replace(' ','').split(',')
    exec_type = parse_args(config.get(step, 'exec_type').replace(' ',''), main_args)
    
    arg_str = ''
    for arg in args:
        arg_val = parse_args(arg, main_args)
        if arg_val == '*' and exec_type == 'cmd':
            if parse_args(config.get(step, 'cmd').replace(' ',''), main_args) == 'rm':
                print('Error: Dangerous rm * operation attempted.')
                raise(Exception)
        arg_str = arg_str + ' ' + arg_val
        
    # check for valid operation
    
    if exec_type not in supported_ops:
        print("Error: Unsupported remote execution operation: "+exec_type)
        raise(Exception)
        
    # don't eval if possible:
    do_eval = False


    if exec_type in ['bash','python','python3']:
            file = parse_args(config.get(step, 'file').replace(' ',''), main_args)
            if ('*') in file:
                do_eval = True
                
                if ('*' not in arg_str):
                    ssh_cmd = '''<<-\'ENDSSH\' eval $\'
    set -e
    filearr=($(find '''+file+'''))
    for ((i=0;i<"${#filearr[@]}";i++));do
        echo '''+exec_type+''' $i '''+arg_str+'''
        '''+exec_type+''' $i '''+arg_str+'''
    done
\'
ENDSSH'''


                else:
                    ssh_cmd = '''<<-\'ENDSSH\' eval $\'
set -e
filearr=($(find '''+file+'''))
argarr=($(find '''+arg_str+'''))
if [ ${#filearr[@]} -ne ${#argarr[@]} ]; then
    echo "Error: Wildcards for scripts and arguements do not return the same numbers!"
    exit 1
fi
for ((i=0;i<"${#filearr[@]}";i++));do
    echo "'''+exec_type+''' ${filearr[$i]} ${argarr[$i]}"
    '''+exec_type+''' ${filearr[$i]} ${argarr[$i]}
done
\'
ENDSSH'''


            else:                
                #ssh_cmd = 'ssh -o StrictHostKeyChecking=no -i '+creds+' '+user+'@'+target+' '+exec_type + ' ' + file + ' ' + arg_str
                ssh_cmd = exec_type + ' ' + file + arg_str


    if exec_type == 'cmd':
            cmd = parse_args(config.get(step, 'cmd').replace(' ',''), main_args)
            ssh_cmd = cmd + arg_str



    if do_eval:
        print(['''ssh''','''-i''',creds,user+'''@'''+target,'eval',ssh_cmd])
        proc = Popen(['''ssh''','''-i''',creds,user+'''@'''+target,'eval',ssh_cmd], stdout=PIPE, stderr=PIPE)
    else:
        print(['''ssh''','''-i''',creds,user+'''@'''+target,ssh_cmd])
        proc = Popen(['''ssh''','''-i''',creds,user+'''@'''+target,ssh_cmd], stdout=PIPE, stderr=PIPE)
     

    comms = proc.communicate() # note this waits for completion
    log = comms[0].decode('ascii') + comms[1].decode('ascii')
    print(log)
    
    return(proc.returncode)
    
def connect_to_build_server(step, config, main_args):
    '''
    Connect to a VM and execute a pipeline on it.
    Assumes the following variables are present and correct in the bash environment: jenkins_build_user, jenkins_build_user_password.
    
    :param str type: remote_build
    :param str host: Hostname of target VM
    :return: 0 if successful
    '''
    
    host = parse_args(config.get(step, 'host').replace(' ',''), main_args)
    
    user = os.environ['jenkins_build_user']
    password = os.environ['jenkins_build_user_password']
    
    if len(user) < 1 or len(password) < 1:
        raise(Exception)
        
    pipeline_dir = main_args['pipeline_name']
    
    # pre-emptive clean
    print('Cleaning build VM')
    cmd = 'rm -rf '+pipeline_dir
    print(cmd)
    ssh = simple_ssh('ssh', host = host, user = user, password = password, execute = cmd)
    if ssh.ret != 0:
        raise(Exception('Error cleaning up pipeline on '+host))
            
    # copy across jenkins directory
    print('Copying accross pipeline to VM')
    cmd = main_args['jenkins_wd']+' '+user+'@'+host+':/home/'+user
    print(cmd)
    ssh = simple_ssh('scp', password = password, execute = cmd)
    if ssh.ret != 0:
        raise(Exception('Error copying pipeline to '+host+' for execution'))
    
    # prepare string of all current arguments
    arg_str = ''
    for key in main_args:
        arg_str = arg_str + ',' + key + '=' + main_args[key]
    arg_str = '\'' + arg_str[1:] + '\''
        
    # execute pipeline
    print('Executing pipeline on VM')
    cmd = 'cd '+pipeline_dir+';python control/DEPLOY/pipeline.py '+main_args['vmpipeline'] + ' ' + arg_str
    print(cmd)
    ssh = simple_ssh('ssh', host = host, user = user, password = password, execute = cmd)
    if ssh.ret != 0:
        raise(Exception('Error executing pipeline on '+host))

    '''
    print('Cleaning up after successful build on VM')
    cmd = 'rm -rf '+pipeline_dir
    print(cmd)
    ssh = simple_ssh('ssh', host = host, user = user, password = password, execute = cmd)
    if ssh.ret != 0:
        raise(Exception('Error cleaning up pipeline on '+host))
    '''
    
    return(0)
    
def update_from_build_server(step, config, main_args):
    '''
    Connect to a VM and copy a folder back to Jenkins.
    Assumes the following variables are present and correct in the bash environment: jenkins_build_user, jenkins_build_user_password.
    
    :param str type: remote_build
    :param str host: Hostname of target VM
    :param str src: Source directory on VM
    :param str dest: Target directory on Jenkins
    :return: 0 if successful
    '''
            
    host = parse_args(config.get(step, 'host').replace(' ',''), main_args)
    src = parse_args(config.get(step, 'src').replace(' ',''), main_args)
    dest = parse_args(config.get(step, 'dest').replace(' ',''), main_args)
    
    user = os.environ['jenkins_build_user']
    password = os.environ['jenkins_build_user_password']
    
    if len(user) < 1 or len(password) < 1:
        raise(Exception)
                    
    # copy across target directory
    cmd = user+'@'+host+':'+src + ' ' + dest
    print(cmd)
    ssh = simple_ssh('scp', password = password, execute = cmd)
    if ssh.ret != 0:
        raise(Exception('Error copying pipeline to '+host+' for execution'))
    
    return(0)

def clean_build_server(step, config, main_args):
    '''
    Connect to a VM and clean the home directory of the user after run.
    Assumes the following variables are present and correct in the bash environment: jenkins_build_user, jenkins_build_user_password.
    
    :param str type: remote_build
    :param str host: Hostname of target VM
    :return: 0 if successful
    '''
    
    host = parse_args(config.get(step, 'host').replace(' ',''), main_args)
    
    user = os.environ['jenkins_build_user']
    password = os.environ['jenkins_build_user_password']
    
    if len(user) < 1 or len(password) < 1:
        raise(Exception)
        
    pipeline_dir = main_args['pipeline_name']
    
    # pre-emptive clean
    print('Cleaning build VM after Run')
    cmd = 'rm -rf '+pipeline_dir
    print(cmd)
    ssh = simple_ssh('ssh', host = host, user = user, password = password, execute = cmd)
    if ssh.ret != 0:
        raise(Exception('Error cleaning up pipeline on '+host))

    return(0)