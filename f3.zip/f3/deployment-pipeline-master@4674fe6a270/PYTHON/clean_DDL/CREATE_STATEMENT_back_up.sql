/*=============================================
-- TABLE              : HR_SF_APPL_RECEIVED_PER_POS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE EXTERNAL HADOOP TABLE IF NOT EXISTS HR_SF_APPL_RECEIVED_PER_POS
(
    APPLICATION_DATE     DATE STORED AS DATE     COMMENT 'System recorded date that an application is received from an applicant for a particular role.',
    APPLICATION_ID     CHAR(20)     COMMENT 'Unique ID number the system generates for an application when a candidate applies to a given role.',
    JOB_REQ_ID     CHAR(20)     NOT NULL      COMMENT 'Unique ID number the system generates when a job Requisition is first created.',
    REQUISITION_STATUS     VARCHAR(20)     NOT NULL      COMMENT 'A job requisition can have any given number of configured statuses outside of the standard, Open, Pending Approval or Closed, and illustrates the present status of a job requisition in the system.',
    APPLICATION_STATUS     VARCHAR(100)     COMMENT 'The status of an applicants application is where the candidate is currently sitting in the Talent Pipeline, i.e., 1st Interview',
    HR_RECRUITER_FIRST_NAME     VARCHAR(100)     NOT NULL      COMMENT 'The designated recruiters first name',
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL      COMMENT 'The designated recruiters last name',
    AGENCY_NAME     VARCHAR(50)     COMMENT 'The business name or otherwise of the Recruitment Agency that forwarded the candidate to the particluar job requisition',
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL      COMMENT 'Warehouse generated field identifying the system action of the accounting record. D = Deleted/Closed; I = Inserted; U = Update',
    LOAD_TIME     VARCHAR(30)     NOT NULL      COMMENT 'None'
    ) 
    STORED AS PARQUETFILE 
    COMMENT 'Actions Infotype - this table captures HR Data in SuccessFactors related to the number of prospective candidate applications received by the AIB on a per Job Requisition basis. From SuccessFactors Saas - Recruitment'
    PARTITIONED BY
    (
       PERIOD_DTE    DATE STORED AS DATE     NOT NULL      COMMENT 'The reporting period for the data in the table. For periodic/monthly tables this is the last working day of the month. For daily tables it is the previous working day.',
       SRCE_SYS    SMALLINT     NOT NULL      COMMENT 'Used for source acctg system for acc and source appl system for appl. Acctg Source Codes: Branch Acctg = 1359, Loan Acctg = 6, Bankmaster = 7, Credit Card = 3.  Appl Source Codes: NAPS = 23, QTS = 26, HMS = 25, CCNAPS = 3',
       SRCE_INST    SMALLINT     NOT NULL      COMMENT 'Used to identify the source institution (or division)  ROI=1, FTB=2, GB=3, Poland=4 (no longer used), Capital Markete=5, Enterprise=6  and EBS=9',
       LOAD_DTE    DATE STORED AS DATE     NOT NULL      COMMENT 'Auto populated System Field of Batch load date'
    )
; 
