# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 11:24:26 2017
Program to amalgamate all Create SQL files used in the SAP HR Acquisition project so they can be used in the Erwin modeling program.
Lines required by Hadoop and not required by Erwin will be removed.

@author: 41774
"""

import re 
import sys
import os
import getopt




regexs = [
        ('CREATE EXTERNAL HADOOP TABLE IF NOT EXISTS','CREATE  TABLE')
        ,('\s*COMMENT\s*\'.*\'',"")
        ,('\s*COMMENT\s*\'.*\n.*\'',"")
        ,('DATE STORED AS DATE','DATE')
        ,('DATE\s*NOT NULL','DATE')
        ,('\s*\)\s*STORED\s+AS.*\n','')
        ,('\s*PARTITIONED\s+BY\s*\(\s*',',\n')
    ]

"""
args = sys.argv[1:]
print(args)
args = args.split()
#args = [i.split('',1)[0] for i in args]
#print(args[0:])
"""




dirPath = "" #Directory path OSwalk is searching through
searchFile = "CREATE_STATEMENT.sql" #name of the file the OSwalk is searching for
outputFile = "DataModelingFile.sql" # name of the output file

try:
    opts, args = getopt.getopt(sys.argv[1:],'p:',['dirPath='])
    
    for p in opts:
        dirPath = p
        
except getopt.GetoptError:
        print("Error Message")
        sys.exit(2)
      
    for opt, arg in opts:
        if opt in ("-d", "--dirPath"):
            dirPath = arg
        elif opt in ("-s", "--searchFile"):
            searchFile = arg
        elif opt in ("-o", "--outputFile"):
            outputFile = arg
 
        print("test")         
    ###repodir = 'D:\\Test Delete This\\'
    #### turn the above into a list for all repos and generate a file for each 
    
    
    ###path = 'D:\\Test Delete This\\'
    ###FileNameClose = 'D:\\Test Delete This\\DataModelingFile.sql'


        
    tfile = open(outputFile,"a")
    for dirs, subdir, files in os.walk(dirPath):
        for file in files:
            if file.startswith(searchFile):
                     fileName = file
     
                     changeLines=''
                     
                     with open(dirs+"\\"+fileName,"r") as tmpfile:
                         for line in tmpfile:
                             #writes the output as one long line adds on each new line
                             changeLines += line
                             
                             # re sub substitutes the comments out, spaces before and after, and resinserts changeLines on new lines
    
                     for pattern, replace in regexs:
                         changeLines = re.sub(pattern, replace, changeLines)
                    
                   
    
                     for line in changeLines:
                                
                                tfile.write(line)
                          
    tfile.close()



