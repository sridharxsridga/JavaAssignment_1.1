# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 11:24:26 2017

@author: 41774
"""

import re 
#import sys
import os

regexs = [
        ('CREATE EXTERNAL HADOOP TABLE IF NOT EXISTS','CREATE  TABLE')
        ,('\s*COMMENT\s*\'.*\'',"")
        #,('\s*COMMENT\s*\'.*\'',"")
        ,('\s*COMMENT\s*\'.*\n.*\'',"")
        ,('DATE STORED AS DATE','DATE')
        ,('DATE\s*NOT NULL','DATE')
        ,('\s*\)\s*STORED\s+AS.*\n','')
        ,('\s*PARTITIONED\s+BY\s*\(\s*',',\n')
    ]

count = 1
repodir = 'D:\\Test Delete This\data-acquisition-hr-data-priority-1-sap\\'
# turn the above into a list for all repos and generate a file for each 

#tmpfile = ''
path = 'D:\\Test Delete This\\data-acquisition-hr-data-priority-1-sap\\'
FileNameClose = 'D:\\Test Delete This\\data-acquisition-hr-data-priority-1-sap\\DataModelingFile.sql'

tfile = open(FileNameClose,"a")
for dirs, subdir, files in os.walk(repodir):
    for file in files:
        if file.startswith("CREATE_STATEMENT.sql"):
                 fileName = file
                 print(dirs)
                 print(subdir)
                 print(fileName)
                 # need to have changeLines as an empty script when changign the read version of the tmpfile
                 changeLines=''
                 
                 with open(dirs+"\\"+fileName,"r") as tmpfile:
                     for line in tmpfile:
                         #writes the output as one long line adds on each new line
                         changeLines += line
                         
                         # re sub substitutes the comments out, spaces before and after, and resinserts changeLines on new lines

                 for pattern, replace in regexs:
                     changeLines = re.sub(pattern, replace, changeLines)
                 """changeLines = re.sub(r'CREATE EXTERNAL HADOOP TABLE IF NOT EXISTS','CREATE  TABLE',changeLines)
                 changeLines = re.sub(r'\s*COMMENT\s*\'.*\'',"",changeLines)
                 changeLines = re.sub(r'DATE STORED AS DATE','DATE',changeLines)
                 changeLines = re.sub(r'DATE\s*NOT NULL','DATE',changeLines)
                 changeLines = re.sub(r'\s*\)\s*STORED\s+AS.*\n','',changeLines)
                 changeLines = re.sub(r'\s*PARTITIONED\s+BY\s*\(\s*',',\n',changeLines)"""

 
                         #tmpfile.close()
                 print(count)
                 count = count + 1
                 #with open(FileNameClose,"a") as tfile:    
                    #    for line in changeLines:
                 for line in changeLines:
                            #will overwrite the file to the new output
                            tfile.write(line)
                      
tfile.close()  


                
"""                 
# need to have changeLines as an empty script when changign the read version of the tmpfile
    changeLines=''
#with open(filePath,"r") as tmpfile:
with open(fileName,"r") as tmpfile:   
    for line in tmpfile:
        #writes the output as one long line adds on each new line
        changeLines += line
# re sub substitutes the comments out, spaces before and after, and resinserts changeLines on new lines 

        changeLines = re.sub(r'CREATE EXTERNAL HADOOP TABLE IF NOT EXISTS','CREATE  TABLE',changeLines)
        changeLines = re.sub(r'\s*COMMENT\s*\'.*\'',"",changeLines)
        changeLines = re.sub(r'DATE STORED AS DATE','DATE',changeLines)
        changeLines = re.sub(r'DATE\s*NOT NULL','DATE',changeLines)
        changeLines = re.sub(r'\s*\)\s*STORED\s+AS.*\n','',changeLines)
        changeLines = re.sub(r'\s*PARTITIONED\s+BY\s*\(\s*',',\n',changeLines)



        tmpfile.close()

FileNameClose = 'D:\\Test Delete This\\data-acquisition-hr-data-priority-1-sap\\DataModelingFile.sql'
with open(FileNameClose,"a") as tfile:    
#    for line in changeLines:
     for line in changeLines:
        #will overwrite the file to the new output
        tfile.write(line)
tfile.close()
"""