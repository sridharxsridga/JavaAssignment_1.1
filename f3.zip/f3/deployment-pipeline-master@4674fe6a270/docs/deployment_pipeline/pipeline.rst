pipeline module
===============

.. automodule:: pipeline
    :members:
    :undoc-members:
    :show-inheritance:
