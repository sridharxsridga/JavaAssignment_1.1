plugins package
===============

Submodules
----------

plugins.executable module
-------------------------

.. automodule:: plugins.executable
    :members:
    :undoc-members:
    :show-inheritance:

plugins.ssh module
------------------

.. automodule:: plugins.ssh
    :members:
    :undoc-members:
    :show-inheritance:

plugins.utilities module
------------------------

.. automodule:: plugins.utilities
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: plugins
    :members:
    :undoc-members:
    :show-inheritance:
