Getting started
===============


The generic deployment pipeline is a tool that can be helpful in setting up new versions of a processing pipeline. It can be executed in Jenkins or with normal python. The flow of a typical (full) deployment is presented in below. Typically as much as the build as possible is done on Jenkins, with some of the steps needing executing on the remote server. Currently additional steps need to be executed on the remote server and their results copied back to Jenkins due to an old python version being installed on Jenkins.

The figure below shows a deployment made up of multiple small steps, which string together to achieve full deployment. This is the default deployment used by many acquisitions. Most steps are dependent on the results of previous steps, so the order of execution is important and can be specified in the 'steps' parameter. The best way to make a new deployment is to copy the configuration file of an existing pipeline, remove the steps which are not required and make any necessary changes to parameters - for example a different schema name could be provided in the Jenkins step. See the next topic on pipeline documentation for full details on how to configure a pipeline, but note that in most cases the only changes needed will be in the Jenkins file.

.. image:: ../images/pipeline_deployment.png

The most common way to run the pipeline is with Jenkins, but it can be executed in any environment. The pipeline can be executed with the command:
::
	python pipeline.py settings.ini 'arg1=value1, arg2=value2'

where the **settings** file is a standard python configuration file describing the steps to take in the pipeline. Optionally *default* can be used here to load the default settings file from the data-acquisition repo. The second argument allows the user to define variables which are then visible to the configuration file. Using a combination of a well-parameterised configuration file and a list of useful variables, the same configuration file can then be used across many similar projects.


List of common variables passed to pipeline
------------------

* *target\_server* - the server to use
* *target\_user* - the user to use
* *jsqsh\_rconn* - the jsqsh connection to use
* *target\_dest* - the target destination
* *vschema* - the schema to use
* *vpathname* - the path to the start of the HDFS directory
* *push\_branch* - the git branch to push against
* *git\_msg* - the git commit message
* *table\_stem* - the stem of the tables to be created, e.g. CALL\*
* *solr\_source\_field* - the source field to use in Solr
* *solr\_cmd* - the solr core to use'

Deployment with Jenkins
------------------

Running the pipeline in a Jenkins environment can be achieved with a small Jenkins file. The file should use Jenkins Git commands to pull both the pipeline repo, and any other repos required for the build. The directories created by the *dir* command are known to the pipeline and can be referenced in the settings file with standard bash substitution notation.

The environment variables *jenkins\_username* and *jenkins\_pipename* should be set before running the pipeline. An appropriate credentials ID should also be used as follows.
::
    node('rhethom2'){
        def userInput = null
        
        stage 'Parameters'
            userInput = input(
             id: 'userInput', message: 'Please input access credentials', parameters: [
             [$class: 'TextParameterDefinition', description: 'Build user', name: 'user'],
             [$class: 'hudson.model.PasswordParameterDefinition', description: 'Build user password', name: 'password']
            ])
            
        stage 'Git fetch'
            dir('project'){
                git branch: 'dev', credentialsId: 'XXXX-XXXX-XXXX', url: 'https://gitstash.aib.pri/scm/hddp/call-data-agent-desktop-services-roi.git'
            }
            dir('control'){
                git branch: 'master', credentialsId: 'XXXX-XXXX-XXXX', url: 'https://gitstash.aib.pri/scm/hea/deployment-pipeline.git'
            }
        
        stage'Run pipeline'
            withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'XXXX-XXXX-XXXX',
                usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {
            withEnv(["jenkins_build_user=${userInput.user}", "jenkins_build_user_password=${userInput.password}"]) {
                sh '''
    jenkins_xml=$(curl -k ${BUILD_URL}api/xml)
    export jenkins_username=$(grep -oPm1 "(?<=<userId>)[^<]+" <<< $jenkins_xml)
    export jenkins_pipename=$(grep -oPm1 "(?<=<fullDisplayName>)[^<]+" <<< $jenkins_xml)
    python control/DEPLOY/pipeline.py vm 'vmhost=rhdatascivt1.mid.aib.pri, vmpipeline=default, target_server=rhhdpomt9.mid.aib.pri, target_user=data_batch, jsqsh_rconn=data_batch, target_dest=/home/data_batch/Pipeline_Deployment/data-acquisition-call-data-icm, vschema=HDCWD00P,vpathname=data,push_branch=dev,git_msg=DSS-10, solr_source_field="Source Field", table_stem=CALL*, solr_cmd=http://rhhdpomt8.mid.aib.pri:8983/solr/Production-Job-Configuration/update?commit=true'
    '''
            }
            }
    }
	
The parameters specified in the second argument are passed to the pipeline, so if one wanted to deploy to a different server in the example above, all one would have to do would be change the *target\_server* parameter to point at the new server and the *target\_user* parameter to be the new login user. Other important parameters include the git commit parameter, \code{git\_msg} and the deployment directory *target\_dest* - note that this directory is usually under the home directory at *\\Pipeline\_Deployment\\<pipeline\_name>*.

Each standard type of deployment (production, production-test, pre-prod, pre-prod test) should have its own Jenkins file already in the repo - differing only by their schemas, target servers and users, git repos and solr cores. Make sure you set the right versions of these when making your own Jenkins file.


Deployment without Jenkins
------------------

The pipeline can also be deployed without Jenkins. The most straightforward way to do this is to clone any required git repos to a src folder on the build system (which can be the same as the target server). This process should be logged, and care should be taken to pull the correct tag/branch (Jenkins would normally log the commit of the branch pulled). You may need to edit the pipeline configuration to give the correct location of any credentials the pipeline might need - alternatively the password can be entered manually when the pipeline is run.

To deploy a **master** version of a pipeline, the recommended process is to first make sure pre-prod is up to date with the exact version required for the master build. Deploy pre-prod once in this form to allow Jenkins (or any build system) to perform any updates to the repo. Then merge pre-prod to master and copy the master repo to the build system, ensuring that the master build with the correct release. Edit the settings.ini file to remove any push to git and perform a build. You may also want to use a different user to make directories/build the tables (this may require moving files to multiple build areas). The build can be performed by using the same python command as in Jenkins, with the addition of any directory names used as extra arguments; i.e. *control=/home/username/mydir/data-acquisition*. Save the logs using > in bash. Note this procedure may change if Jenkins is allowed access to production environments. A sample command looks like
::
	python data-acquisition-deployment-pipeline/DEPLOY/pipeline.py default 'target_server=rhhdpalp9.mid.aib.pri, target_user=data_batch, jsqsh_rconn=data_batch, target_dest=/home/data_batch/Pipeline_Deployment/data-acquisition-hr-data-priority-1-sap, vschema=HDCWD00P,vpathname=data,push_branch=master,git_msg=DSS-10, solr_source_field="Source Field Short Description", table_stem=HR*, solr_cmd=http://rhhdpalp8.mid.aib.pri:8983/solr/Production-Job-Configuration/update?commit=true, control=/opt/scripts/DataInnovation/ProductionScripts/Pipeline_Deployment/src/data-acquisition-deployment-pipeline, project=/opt/scripts/DataInnovation/ProductionScripts/Pipeline_Deployment/src/data-acquisition-hr-data-priority-1-sap' > mylog.txt

N.B. Currently the directory creation script changes the original file in the data-acquisition-deployment-pipeline repo, so subsequent runs will fail to create the right directories as the regex will fail. Either update the data-acquisition each step, or just manually reset the .cfg file.


Dependencies
------------------
The pipeline and scheduler are dependent on a number of python scripts, which themselves have some additional dependencies (such as Python3). The dependencies installed on the production environment are listed below. Some steps of the default pipeline also directly call the python scripts located in the python folder of the data-acquisition repository. The dependencies of those scripts are included below.

.. code-block:: bash

	et_xmlfile-1.0.1.tar.gz   jdcal-1.3.tar.gz          numpy-1.12.1.zip       pyasn1-0.2.3.tar.gz          py-dateutil-2.2.tar.gz  Python-3.6.0.tgz              requests-2.13.0.tar.gz   twofish-0.3.0.tar.gz   zlib-1.2.11.tar.gz
	ibm_db-2.0.7.tar.gz       linuxx64_odbc_cli.tar.gz  openpyxl-2.4.2.tar.gz  pyasn1-modules-0.0.8.tar.gz  pyjks-17.0.0.tar.gz     python-dateutil-2.6.0.tar.gz  six-1.10.0.tar.gz        unixODBC-2.3.4.tar.gz
	javaobj-py3-0.2.3.tar.gz  numexpr-2.6.2.tar.gz      pandas-0.19.2.tar.gz   pycrypto-2.6.1.tar.gz        pyodbc-4.0.17.tar.gz    pytz-2016.10.tar.gz           SQLAlchemy-1.1.6.tar.gz  xlrd-1.0.0.tar.gz



