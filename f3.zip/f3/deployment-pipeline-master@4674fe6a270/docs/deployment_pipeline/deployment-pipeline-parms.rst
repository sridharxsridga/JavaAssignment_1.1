Pipeline Configuration
===============


The generic pipeline is modular in design and can be configured with a standard python configuration (.ini) file. This file must defines multiple sections, each with its own variables.

The control step
------------------

A step with *type = control* is mandatory and must be defined as follows:
::
	[control]
	# Mandatory parameters: steps, creds
	steps = clean_target,make_new_target_directory
	type = control
	creds = /home/jenkins/.ssh/id_rsa_data

This command tells the pipeline that any credentials to execute the steps *clean\_target* and *make\_new\_target\_directory*. Note that the name of the section is for labelling purposes only - it is the *type* parameter that tells the pipeline what arguments to expect.

General steps
------------------

The *clean\_target* step can then be defined along the lines of
::
	[clean_target]
	type = remote_exec
	target = ${target_server}
	user = ${target_user}
	cmd = rm
	args = -rf,${target_dest}
	exec_type = cmd

where *\$\{\}* notation is used to substitute variables defined when calling the pipeline.


List of supported steps
------------------

See the following list of :mod:`~plugins` for a list of supported step types and their arguments.

