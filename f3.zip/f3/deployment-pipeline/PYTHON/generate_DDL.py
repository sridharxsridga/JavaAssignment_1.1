# -*- coding: utf-8 -*-
"""
Created on Thu Dec 22 10:51:25 2016

This file will generate the relevant SQL scripts 
using Mapping documents

@author: 35446
"""

import csv
import os
import argparse
import warnings
import openpyxl
import xlrd
from datetime import datetime
k = datetime.now()
import getpass
import textwrap
from collections import defaultdict

warnings.filterwarnings("ignore")

bad_sheets = ['Version Control', 'Approvals', 'Overview', 'Table Vol & Delta Logic Summary', 'Stakeholder Requirements', 'Process Flow', '_Template','PCI_PII_EXAMPLE']

parser = argparse.ArgumentParser(description = 'Generate DDL from Mapping Document.')
parser.add_argument('dir_name', type = str, help = 'The directory path to the files.')
parser.add_argument('output_dir_name', type = str, help = 'The directory path to the output files.')
parser.add_argument('--staging', action = "store_true", help = 'Generate the staging table INSTEAD of the normal one.')
parser.add_argument('--edw', action = "store_true", help = 'Generate the edw table INSTEAD of the normal one.')
parser.add_argument('--hive_hist', action = "store_true", help = 'Generate the procedure for historic INSTEAD of the normal one.')
parser.add_argument('--verbose', action = "store_true", help = 'Increase output verbosity')

args = parser.parse_args()
user = getpass.getuser()
if(args.verbose):
    loud = True
else:
    loud = False

tabledef = defaultdict(list)
table_def = ""
insert_def = ""

"""Loop through files in directory"""
for root, dirs, files in os.walk(args.dir_name):    
    for file in files:
        wb = openpyxl.load_workbook(os.path.join(root,file), data_only=True)
        sheets = wb.get_sheet_names()
        sheet_names = [item for item in sheets if item not in bad_sheets]

        field_list = u"Target \nSchema or \nDatabase"
        tablecomments = [u"Table level Metadata:"]

        headerdesc = defaultdict(dict)

        """Loop through sheets"""
        for i in sheet_names:
            tabledef = defaultdict(list)
            ws = wb.get_sheet_by_name(i)
            #print("\n")
            meta=[]
            table_def = ""
            insert_def = ""
            table_name = ""
            create_table = ""
            header = ""
            analyzelist = ""
            partitions = ""
            insert_part = ""
            nulls=set()
            partitionslist=[]
            
            start, stop, colstart, colstop = None, None, None, None


            """Find the last column containing a value"""
            for column in reversed(list(ws.columns)):
                values = [cell.value for cell in column]
                if any(values):
                    colstop = "{0}".format(column[0].column)
                    break
            
            """Loop through sheet to find cell that is = field_list and return the range of cells on it's row"""
            
            for row in ws:
                for cell in row:
                    try:
                        if cell.value == field_list:
                            start, stop, colstart = cell.row, cell.row, cell.column
                            #print (start, stop, colstart, colstop)
                            break
                    except:
                        print(cell)
            
            #print (start, stop, colstart, colstop)

            """Loop through columns in that range to get values"""
            for col in ws.iter_rows('{}{}:{}{}'.format(colstart, start, colstop, stop)):
                for cell in col:
                    try:
                        meta.append(cell.value.strip())
                    except AttributeError:
                        print('Irregular number of columns detected.')
                        print('cell.value = '+str(cell.value))
                        print('cell = '+str(cell))
                        print('col = '+str(col))
                #print(meta)

            """Loop through worksheet and cell and stop the loop if the column contains no values."""
            for row in ws:
                for cell in row:
                    if cell.value in tablecomments:
                        tblcmnt = str(ws[chr(ord(cell.column) + 1) + str(cell.row)].value).strip()
                        tblcmnt = tblcmnt.replace("'","")
                        #print(tblcmnt)
                    if cell.value == field_list:
                        start, stop, colstart, colstop = cell.row + 1, ws.max_row, cell.column, cell.column
                        breakout = False
                        for stoprow in ws.iter_rows('{}{}:{}{}'.format(colstart, start, colstop, stop)):
                            if breakout:
                                break
                            for stopcell in stoprow:
                                if not stopcell.value:
                                    stop = stopcell.row
                                    breakout = True
                                    break
                                else:
                                    """create a matrix of values for the cells in the range"""
                                    for i, a in enumerate(meta):
                                        offset = ''
                                        if chr(ord(stopcell.column)+i%25) > 'Z':
                                            if offset == '':
                                                offset = 'A'
                                            else:
                                                offset = chr(ord(offset)+1)
                                        tabledef[a].append(
                                            str(ws[offset+chr(ord(stopcell.column) + i%25) + str(stopcell.row)].value).strip())
                                            
            tablemeta = {}
            """Get the table level metadata"""
            for row in ws:
                for cell in row:
                    if cell.value == u"Hadoop/Hive Target Table" or cell.value == u"Target Table  ":
                        main_table_ref = cell.value.strip()
                        start, stop, colstart, colstop = cell.row, ws.max_row, cell.column, cell.column
                        breakout = False
                        for stoprow in ws.iter_rows('{}{}:{}{}'.format(colstart, start, colstop, stop)):
                            if breakout:
                                break
                            for stopcell in stoprow:
                                if not stopcell.value:
                                    stop = stopcell.row
                                    breakout = True
                                    break
                                else:
                                    tablemeta[stopcell.value.strip()] = str(
                                        ws[chr(ord(stopcell.column) + 1) + str(stopcell.row)].value).strip()
            


            """get table name from matrix"""
            if args.staging:
                try:
                    table_name = tablemeta[u"Hadoop/Hive Target Staging Table"]
                    output_table_dir = tablemeta[u"Hadoop/Hive Target Table"] if u"Hadoop/Hive Target Table" in tablemeta else tablemeta[u"Target Table"]
                except:
                    print('Unable to find staging table information for Sheet in '+file+'. Skipping it.')
                    continue
                stored_as = tablemeta[u"Target Staging Data Stored as"]
            elif args.edw:
                try:
                    table_name = tablemeta[u"EDW Target Table"]
                    output_table_dir = tablemeta[u"Target Table"]
                    edw_schema = tablemeta[u"EDW Target Schema/Database"]
                    edw_settings = "\n,NO FALLBACK\n, NO BEFORE JOURNAL\n, NO AFTER JOURNAL\n, CHECKSUM = DEFAULT\n, DEFAULT MERGEBLOCKRATIO"
                except:
                    print('Unable to find edw table information for Sheet in '+file+'. Skipping it.')
                    continue
                stored_as = ""
            else:
                table_name = tabledef[u"Hadoop/Hive Target Table"][0] if u"Hadoop/Hive Target Table" in tabledef else tabledef[u"Target Table"][0]
                table_schema = tablemeta[u"Target Production Schema/Database"]
                output_table_dir = table_name
                try:
                    stored_as = tabledef[u"Target Data stored as "][0]
                except:
                    stored_as = 'PARQUETFILE'
            
            if stored_as.upper().strip() == 'PARQUET':
                stored_as = 'PARQUETFILE'
            elif stored_as.upper().strip() == 'TEXT':
                stored_as = 'TEXTFILE'

            """Get Not NULLABLE fields"""
            for i,x in enumerate(tabledef[u"NULLABLE"]):
                if x == 'N':
                    nulls.add(tabledef[u"Target Field"][i])
            #print(nulls)
            
            """get fields to partition on"""
            for i,x in enumerate(tabledef[u"Partitioned Column"]):
                try:
                    partitionslist.append((int(x),i,tabledef[u"Target Field"][i]))  
                except:
                    continue


            partitionfields = [(i,y) for x,i,y in sorted(partitionslist)]
            #print(partitionfields)

            partitionnames = [y for x,i,y in partitionslist]
            #print(partitionnames)

            data_type_col = u"Hadoop/Hive Target Data Type" if u"Hadoop/Hive Target Data Type" in tabledef else u"Target Data Type"
            for i,x in partitionfields:
                not_null = " NOT NULL " if x in nulls else ""
                insert_part += tabledef[u"Target Field"][i] + ",\n"
                partitions += tabledef[u"Target Field"][i] + textwrap.indent(tabledef[data_type_col][i],'    ') + textwrap.indent(not_null,'    ') + textwrap.indent(" COMMENT '",'    ') + tabledef[u"Metadata"][i] + "',\n"
            partitions = partitions[:-2]+"\n".strip()
            insert_part = insert_part[:-2]+"\n".strip()
            
            """replace any TIMESTAMP_AS_VARCHAR with VARCHAR"""
            for i in range(len(tabledef[data_type_col])):
                if 'TIMESTAMP_AS_VARCHAR' in tabledef[data_type_col][i]:
                    tabledef[data_type_col][i] = tabledef[data_type_col][i].replace('TIMESTAMP_AS_VARCHAR','VARCHAR')
            
            """replace any DATE STORES AS DATE with DATE and add in CHARACTER SET LATIN and change DOUBLE TO DOUBLE PRECISION... if VARCHER when edw is set """
            if args.edw:
                for i in range(len(tabledef[data_type_col])):
                    if 'DATE STORED AS DATE' in tabledef[data_type_col][i]:
                        tabledef[data_type_col][i] = tabledef[data_type_col][i].replace('STORED AS DATE','')
                for i in range(len(tabledef[data_type_col])):        
                    if 'CHAR' in tabledef[data_type_col][i]:
                        tabledef[data_type_col][i] = tabledef[data_type_col][i]+" CHARACTER SET LATIN NOT CASESPECIFIC"
                for i in range(len(tabledef[data_type_col])):        
                    if 'DOUBLE' in tabledef[data_type_col][i]:
                        tabledef[data_type_col][i] = tabledef[data_type_col][i]+" PRECISION"
        	
            for i in range(len(tabledef[u"Metadata"])):
            	if "'" in tabledef[u"Metadata"][i]:
            		tabledef[u"Metadata"][i] = tabledef[u"Metadata"][i].replace("'","")
            
            """Get list of fields and data types, in correct order, for create statement"""
            fields = [(tabledef[u"Target Field"].index(y),y) for x,y in sorted(zip([int(i) for i in tabledef[u"Target Position"]], tabledef[u"Target Field"]))]
            for a,x in fields:
                not_null = " NOT NULL " if x in nulls else ""
                if args.edw:
                    table_def += x + " " + textwrap.indent(tabledef[data_type_col][a],'    ') + ",\n"
                elif x not in partitionnames or args.staging:
                    insert_def += x + ",\n"
                    table_def += x + " " + textwrap.indent(tabledef[data_type_col][a],'    ') + textwrap.indent(not_null,'    ') + textwrap.indent(" COMMENT '",'    ') + tabledef[u"Metadata"][a] + "',\n"
            #insert_def = insert_def[:-2]+"\n".strip()
            table_def = table_def[:-2]+"\n".strip()
            if args.hive_hist:
                hive_header = "set mapreduce.map.memory.mb=5120;\nset mapreduce.map.java.opts=-Xmx4608m;\nset mapreduce.reduce.memory.mb=5120;\nset mapreduce.reduce.java.opts=-Xmx4608m;\nset hive.optimize.sort.dynamic.partition=true;\n\n"

            
            """Get list of fields list of columns to analyse"""
            for c in tabledef[u"Target Field"]:
                analyzelist += c + ",\n"
            analyzelist = analyzelist[:-2]+"\n".strip()
            #print(analyzelist)
            
            """Create header description dictionary to help create header for each file"""
            if args.staging:
                headerdesc["create"] = {
                "procedure":"CREATE_STATEMENT.sql",
                "function":"Create staging table",
                "steps":"---------",
                "desc":"This file creates the \nnecessary staging table.",
                "statement":"\n\n\nCREATE HADOOP TABLE IF NOT EXISTS " + table_name.upper()+ "\n(\n" + textwrap.indent(table_def,'    ') + textwrap.indent("\n) \nSTORED AS "+stored_as.upper()+"\nCOMMENT '" + tblcmnt,'    ') + "'\n;\n"
                }
            elif args.edw:
                headerdesc["create"]= {
                "procedure":"CREATE_STATEMENT.sql",
                "function":"Create staging table",
                "steps":"---------",
                "desc":"This file creates the \nnecessary edw table.",
                "statement":"\n\nCREATE MULTISET TABLE "+edw_schema.upper()+"."+table_name.upper()+edw_settings+"\n(\n" + textwrap.indent(table_def,'    ') + textwrap.indent("\n) NO PRIMARY INDEX; ", ' ')  
                }
            elif args.hive_hist:
                headerdesc["hive_insert"] = {
                "procedure":"HIVE_INSERT.sql",
                "function":"inserts",
                "steps":"---------",
                "desc":"inserts into historic table to fix period_dte issue.",
                "statement":hive_header + "INSERT INTO TABLE " + table_schema.upper() + "." + table_name.upper().replace("_RAW", "_HIST") + "\nPARTITION \n(" + insert_part + "\n)\nSELECT\n" + textwrap.indent(insert_def,'    ') + textwrap.indent(insert_part,'    ') + "\n FROM " + table_schema.upper() + "." + table_name.upper() + "\n\nDISTRIBUTE BY DATE()\n;"
                }
            else:
                headerdesc["create"] = {
                "procedure":"CREATE_STATEMENT.sql",
                "function":"Create table",
                "steps":"---------",
                "desc":"This file creates the \nnecessary table.",
                "statement":"\n\n\nCREATE EXTERNAL HADOOP TABLE IF NOT EXISTS " + table_name.upper()+ "\n(\n" + textwrap.indent(table_def,'    ') + textwrap.indent("\n) \nSTORED AS "+stored_as.upper()+" \nCOMMENT '" + tblcmnt + "'\nPARTITIONED BY\n(\n",'    ') + textwrap.indent(partitions, '       ') + textwrap.indent("\n)",'    ') + "\n; \n"
                }
            headerdesc["create_view"] = {
            "procedure":"CREATE_VIEW_STATEMENT.sql",
            "function":"Create view statement",
            "steps":"---------",
            "desc":"This is a view of the table that stores the data.",
            "statement":"\n\n\nCREATE OR REPLACE VIEW " + table_name.upper()+ "\n\nAS\n\nSELECT *\nFROM\nHDCWD00P." + table_name.upper() + "\n;\n\n"
            }
            headerdesc["analyze"] = {
            "procedure":"ANALYZE_STATEMENT.sql",
            "function":"Analyze table",
            "steps":"---------",
            "desc":"This file gathers \nstatistics on the table.",
            "statement":"\n/*\n ANALYZE TABLE " + table_name.upper() + textwrap.indent("\nCOMPUTE STATISTICS", '    ') + textwrap.indent(" \nFOR COLUMNS (\n",'    ') + textwrap.indent(analyzelist,'        ') + "\n)\n;\n*/"
            }
            headerdesc["alter"] = {
            "procedure":"ALTER_STATEMENT.sql",
            "function":"Alter table",
            "steps":"---------",
            "desc":"This file alters the \ntable to add columns.",
            "statement":"\n/*\n ALTER TABLE " + table_name.upper() + " ADD (INSERT COLUMN NAME) (INSERT DATA TYPE HERE);\n*/"
            }
            headerdesc["drop"] = {
            "procedure":"DROP_STATEMENT.sql",
            "function":"Drop table",
            "steps":"---------",
            "desc":"This file drops the table.",
            "statement":"\n\n DROP TABLE IF EXISTS " + table_name.upper() + ";"
            }
            headerdesc["drop_view"] = {
            "procedure":"DROP_VIEW_STATEMENT.sql",
            "function":"Drop view",
            "steps":"---------",
            "desc":"This file drops the view of a table.",
            "statement":"\n\n /*DROP VIEW " + table_name.upper() + ";*/"
            }
            headerdesc["grant"] = {
            "procedure":"GRANT_STATEMENT.sql",
            "function":"Grant on table",
            "steps":"---------",
            "desc":"This file grants select \naccess to the the table.",
            "statement":"\n\n GRANT SELECT ON " + table_name.upper() + " TO USER_DATA ;"
            }
            headerdesc["trunc"] = {
            "procedure":"TRUNCATE_STATEMENT.sql",
            "function":"Truncate table",
            "steps":"---------",
            "desc":"This file truncates \nthe table.",
            "statement":"\n\n TRUNCATE TABLE " + table_name.upper() + " ;"
            }
            
            """Loop through headerdesc and generate header and output statemenr"""
            for key in headerdesc:
                table = "\n-- TABLE              : " + str(table_name)
                procedure = "\n-- PROCEDURE          : " + str(headerdesc[key]["procedure"])
                function = "\n-- FUNCTION           : " + str(headerdesc[key]["function"])
                steps = "\n-- STEPS              : " + str(headerdesc[key]["steps"])
                author = "\n-- AUTHOR             : " + str(user)
                #create_date = "\n-- CREATE DATE        : " + k.strftime('%d/%m/%Y %H:%M:%S') # removing this to help id changes in git
                descr = "\n\n-- DESCRIPTION        : " + str(headerdesc[key]["desc"])
                statement = str(headerdesc[key]["statement"])
                header = "/*=============================================" + table + procedure + function + steps + author + descr + "\n\n\n-- ============================================*/"
                if args.hive_hist:
                    output = statement
                else:
                    output = header + statement
                #print(output)
                """Create file directory and write files to it"""
                if args.staging:
                    file_tail = headerdesc[key]["procedure"].split('.')[0]+'_STG.sql'
                    filename = os.path.join(args.output_dir_name, output_table_dir+"/BigSQL"+"/"+file_tail)
                elif args.edw:
                    file_tail = headerdesc[key]["procedure"].split('.')[0]+'_EDW.sql'
                    filename = os.path.join(args.output_dir_name, output_table_dir+"/EDW"+"/"+file_tail)
                elif args.hive_hist:
                    filename = os.path.join(args.output_dir_name, output_table_dir+"/BigSQL"+"/"+headerdesc[key]["procedure"])
                else:
                    filename = os.path.join(args.output_dir_name, output_table_dir+"/BigSQL"+"/"+headerdesc[key]["procedure"])
                os.makedirs(os.path.dirname(filename), exist_ok=True)
                text_file = open(filename,"w",encoding = 'utf-8')
                text_file.write(output)
                text_file.close()