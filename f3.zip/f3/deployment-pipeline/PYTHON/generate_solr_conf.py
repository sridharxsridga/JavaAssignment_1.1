# -*- coding: utf-8 -*-
"""

This file will generate the relevant SOLR configuration using the mapping document

@author: 41954

"""

import argparse
import datetime
import json
import os
import warnings
from collections import defaultdict
import openpyxl
import re

k = datetime.datetime.now()
warnings.filterwarnings("ignore")

"""Processing arguments"""
parser = argparse.ArgumentParser(description='Generate SOLR Configuration from Mapping Document.')
parser.add_argument('dir_name', type=str, help='The directory path to the files.')
parser.add_argument('--fs_prefix', type=str, help='prefix to add if we use a different filesystem. E.g. "bigpfs"',
                    default="")
parser.add_argument('--prefix_dir', type=str, help='prefix data directory. E.g. "data" or "test_data"',
                    default="data")
parser.add_argument('--name_node', type=str, help='spark name node location, e.g. file://rhhdpomt9.mid.aib.pri/',
                    default="file://rhhdpomt9.mid.aib.pri/")
parser.add_argument('--schema', type=str, help='overwrite schema with custom one, e.g. HDCWD00S', default="")
parser.add_argument('--source_field', type=str, help="Column name in the metadata file(case sensitive) that contains the source field matching the header (default: Source Field)", default="Source Field")
parser.add_argument('--split_broken_lines', type=str, help="Filter out broken lines without rejecting the file? Default false", default="false")
parser.add_argument('--tablelevel_quality_tablename', type=str, help="Name of the tablelevel quality table. Default: targetschema.HADOOP_DQ_JOB_TABLE_QUALITY_D2", default="HADOOP_DQ_JOB_TABLE_QUALITY_D2")
parser.add_argument('--columnlevel_quality_tablename', type=str, help="Name of the columnlevel quality table. Default: targetschema.HADOOP_DQ_JOB_TABLE_QUALITY_D2", default="HADOOP_DQ_JOB_COLUMN_QUALITY_D2")
parser.add_argument('--quality_hostname', type=str, help="Hostname of the quality database. Default: rhhdpomt9.mid.aib.pri", default="rhhdpomt9.mid.aib.pri")
parser.add_argument('--quality_user', type=str, help="User to connect to quality database with. Default: data_batch", default="data_batch")
parser.add_argument('--quality_port', type=str, help="Port of the quality database. Default: 32051", default="32051")
parser.add_argument('--executor_memory', type=str, help="Amount of memory per executor", default="8G")

args = parser.parse_args()

"""Solr configuration helper functions"""


def __get_solr_filename_extract(tablemeta):
    """
    Generates the FILE_NAME_EXTRACT field
    :param tablemeta: table metadata
    :return: FILE_NAME_EXTRACT
    """
    pattern = r'<*[A-Za-z][\w\-]+>*'
    components_list = re.findall(pattern, tablemeta["Source Filename"])
    new_components = []
    for i, c in enumerate(components_list):
        if c[0] == "<":
            x = "<"+"".join([x for x in filter(str.isalnum, c)])+">"
            new_c = "(?" + x + ".*?)"
        elif i == 0:
            new_c = "(?<prefix>" + c + ")"
        else:
            new_c = ""
        new_components.append(new_c)
    new_components.append("(?<ext>\\\\." + tablemeta["File Type"].replace(".", "") + ")")
    return "".join(new_components)


def __get_solr_target_filename(tabledef):
    """
    Generates target filename
    :param tabledef: table definition
    :return: target filename
    """
    pattern = r'<+[A-Za-z]\w+>+'
    components_list = re.findall(pattern, tabledef["Target Filename"]) if tabledef["Target Filename"] != "None" else re.findall(pattern, tabledef["Source Filename"])
    cleaned_components = ["("+"".join([ch for ch in filter(str.isalnum, c)])+")" for c in components_list]
    name = tabledef["Target Filename"] if tabledef["Target Filename"] != "None" else tabledef["Source Filename"]
    for i, c in enumerate(components_list):
        name = name.replace(c, cleaned_components[i])
    return name+"(ext)" if ("(ext)" not in name.lower() and "txt" not in name.lower() and "csv" not in name.lower() and "xls" not in name.lower() and "json" not in name.lower()) else name


def __get_transformations(s):
    """
    Returns the transformation list to apply
    """
    pattern = """(?<=\{).*(?=\})"""
    transformationstr = re.findall(pattern, s)
    if transformationstr:
        transformations = transformationstr[0]
        return transformations.strip(" ")
    else:
        return ""

def __get_solr_columns(tablemeta, tabledef, columnlist, partition=True):
    """
    Generates PARTITIONS and ADDED_COLUMNS
    :param tablemeta: table metadata
    :param tabledef: table definition
    :param columnlist: list of columns to generate
    :return: PARTITIONS or ADDED_COLUMNS
    """

    def __get_solr_order(p, tabledef):
        """
        :param p: partition or added column name
        :param tabledef: table definition
        :return: position for the partition
        """
        i = tabledef[u"Target Field"].index(p)
        order = tabledef[u"Partitioned Column"][i] if partition else tabledef[u"Target Position"][i]
        return order


    def __get_solr_target_position(p, tabledef):
        """
        :param p: partition or added column name
        :param tabledef: table definition
        :return: position for the partition
        """
        i = tabledef[u"Target Field"].index(p)
        target_pos = tabledef[u"Target Position"][i]
        return target_pos


    def __get_solr_value(p, tabledef):
        """
        Returns the default value
        :param p: partition or added column name
        :param tabledef: table definition
        :return: default value if it exists, empty string if it doesn't
        """
        i = tabledef[u"Target Field"].index(p)
        return tabledef["Default Value"][i] if tabledef["Default Value"][i] != "None" else ""

    def __get_solr_from_format(p, tabledef):
        """
        Returns the format of dates/timestamps in the source file
        :param p: partition or added column name
        :param tabledef:  table definition
        :return: format or empty string
        """
        i = tabledef[u"Target Field"].index(p)
        return tabledef['Source Data Type Format'][i].replace("Y","y").replace("D","d") if tabledef['Source Data Type Format'][i] != "None" else ""

    def __get_solr_format(p, tabledef):
        """
        Returns the format to which the date must be transformed to.
        :param p: name of the partition or added column
        :param tabledef: table definition
        :return: format or empty string
        """
        i = tabledef[u"Target Field"].index(p)
        return tabledef['Target Data Type Format'][i].replace("Y","y").replace("D","d") if tabledef['Target Data Type Format'][i] != "None" else ""

    def __get_solr_from(p, tabledef):
        """
        Returns where spark should retrieve the field information from
        :param p: partition or added column name
        :param tabledef: table definition
        :return: source where spark should retrieve the field information from
        """
        solr_type = __get_solr_type(p, tabledef)
        if solr_type == "text":
            return "solr"
        elif p == "PERIOD_DTE":
            return "run_control"
        elif p in ['LOAD_DTE', "LOAD_TIME"]:
            return "server"
        else:
            return "record"

    def __get_solr_type(p, tabledef):
        """
        Returns the type of the field
        :param p: partition or added column name
        :param tabledef: table definition
        :return: type
        """
        i = tabledef[u"Target Field"].index(p)
        sql_type = tabledef[u"Hadoop/Hive Target Data Type"][i] if u"Hadoop/Hive Target Data Type" in tabledef else tabledef[u"Target Data Type"][i]
        solr_type = None
        if "DATE" in sql_type:
            solr_type = "date"
        elif "TIMESTAMP" in sql_type:
            solr_type = "timestamp"
        else:
            solr_type = "text"
        return solr_type

    cols = {}
    for p in columnlist:
        c = p.lower()
        cols[c] = {"type": __get_solr_type(p, tabledef),
                   "from": __get_solr_from(p, tabledef),
                   "order": __get_solr_order(p, tabledef),
                   "target_position": __get_solr_target_position(p, tabledef)}
        if cols[c]["from"] == "solr":
            cols[c]["value"] = __get_solr_value(p, tabledef)
        if cols[c]["type"] == "date":
            file_format = tablemeta["Date format"].replace("Y", "y").replace("D","d") if tablemeta["Date format"] != "None" else "yyyyMMdd"
            cols[c]["from_format"] = __get_solr_from_format(p, tabledef) if cols[c]["from"] != "file" else file_format
            cols[c]["format"] = __get_solr_format(p, tabledef)
    return json.dumps(cols)


tabledef = defaultdict(list)


"""Loop through files in directory"""
for root, dirs, files in os.walk(args.dir_name):
    for f in files:

        wb = openpyxl.load_workbook(os.path.join(root, f), data_only=True)
        sheets = wb.get_sheet_names()
        sheet_names = [item for item in sheets if wb.get_sheet_by_name(item)['a1'].value == "Mapping Doc"]
        field_list = u"Target \nSchema or \nDatabase"
        tablecomments = [u"Target Table", u"Hadoop/Hive Target Table"]

        headerdesc = defaultdict(dict)

        """ Decide if the job should compare the row count with the number of rows declared in the file (usually in header or footer)
            If rows should be monitored, then provide a regex to interpret the row count
        """
        monitor_rows = ""
        count_re = ""
        if "epi_use" in f.lower() or "epiuse" in f.lower() or any("epi_use" in s.lower() for s in sheet_names) or any("epiuse" in s.lower() for s in sheet_names):
            if 'HR_SAPDATA_EPIUSE-Priority7' not in f:
                monitor_rows = "last"
                count_re = "(?<=ROWS: )\\\\d+"
        elif "cornerstone" in f.lower():
            monitor_rows = "1"
            count_re = "(?<=# Records: )\\\\d+"
        elif "axa" in f.lower():
            monitor_rows = "last"
            count_re = "(?m)(?<=0xA6)\\\\d+$"          #To get the No of records sent from the source that is always the last column in the last record and the delimeter is 0xA6
    
        """Loop through sheets"""
        for sheet in sheet_names:

            tabledef = defaultdict(list)
            ws = wb.get_sheet_by_name(sheet)
            meta = []
            table_def = ""
            table_name = ""
            create_table = ""
            header = ""
            analyzelist = ""
            partitionslist = []
            colstop = None
            colstart = None
            start = None
            stop = None

            """Find the last column containing a value"""
            for column in reversed(list(ws.columns)):
                values = [cell.value for cell in column]
                if any(values):
                    colstop = "{0}".format(column[0].column)
                    break

            """Loop through sheet to find cell that is = field_list and return the range of cells on it's row"""
            for row in ws:
                for cell in row:
                    if cell.value == field_list:
                        start, stop, colstart = cell.row, cell.row, cell.column

            """Loop through columns in that range to get values"""
            for col in ws.iter_rows('{}{}:{}{}'.format(colstart, start, colstop, stop)):
                for cell in col:
                    try:
                        meta.append(cell.value.strip())
                    except AttributeError:
                        print('Irregular number of columns detected.')
                        print('cell.value = ' + str(cell.value))
                        print('cell = ' + str(cell))
                        print('col = ' + str(col))
                        

            """Loop through worksheet and cell and stop the loop if the column contains now values."""
            for row in ws:
                for cell in row:
                    if cell.value in tablecomments:
                        tblcmnt = str(ws[chr(ord(cell.column) + 1) + str(cell.row)].value).strip()
                    if cell.value == field_list:
                        start, stop, colstart, colstop = cell.row + 1, ws.max_row, cell.column, cell.column
                        breakout = False
                        for stoprow in ws.iter_rows('{}{}:{}{}'.format(colstart, start, colstop, stop)):
                            if breakout:
                                break
                            for stopcell in stoprow:
                                if not stopcell.value:
                                    stop = stopcell.row
                                    breakout = True
                                    break
                                else:
                                    """create a matrix of values for the cells in the range"""
                                    for i, a in enumerate(meta):
                                        offset = ''
                                        if chr(ord(stopcell.column)+i%25) > 'Z':
                                            if offset == '':
                                                offset = 'A'
                                            else:
                                                offset = chr(ord(offset)+1)
                                        tabledef[a].append(
                                            str(ws[offset+chr(ord(stopcell.column) + i%25) + str(stopcell.row)].value).strip())

            """get fields to partition on"""
            for i, x in enumerate(tabledef[u"Partitioned Column"]):
                if x in ('1', '2', '3', '4'):
                    partitionslist.append(tabledef[u"Target Field"][i])

            tablemeta = {}
            """Loop through worksheet and cell and stop the loop if the column contains now values."""
            for row in ws:
                for cell in row:
                    if cell.value == u"Hadoop/Hive Target Table" or cell.value == u"Target Table  ":
                        main_table_ref = cell.value.strip()
                        start, stop, colstart, colstop = cell.row, ws.max_row, cell.column, cell.column
                        breakout = False
                        for stoprow in ws.iter_rows('{}{}:{}{}'.format(colstart, start, colstop, stop)):
                            if breakout:
                                break
                            for stopcell in stoprow:
                                if not stopcell.value:
                                    stop = stopcell.row
                                    breakout = True
                                    break
                                else:
                                    tablemeta[stopcell.value.strip()] = str(
                                        ws[chr(ord(stopcell.column) + 1) + str(stopcell.row)].value).strip()


            """Loop through sheet to find cell that is = field_list and return the range of cells on it's row"""
            for row in ws:
                for cell in row:
                    if cell.value == "Scheduling Table":
                        start, stop, colstart = cell.row, cell.row, cell.column
                        for cell in row:
                            if cell.value:
                                colstop = cell.column
                        break

            meta = []
            """Loop through columns in that range to get values"""
            for col in ws.iter_rows('{}{}:{}{}'.format(colstart, start, colstop, stop)):
                for cell in col:
                    try:
                        meta.append(cell.value.strip())
                    except AttributeError:
                        print('Irregular number of columns detected.')
                        print('cell.value = ' + str(cell.value))
                        print('cell = ' + str(cell))
                        print('col = ' + str(col))


            """Loop through worksheet and cell and stop the loop if the column contains scheduler values."""
            scheduler_conf = defaultdict(list)
            for row in ws:
                for cell in row:
                    if cell.value == "Scheduling Table":
                        tblcmnt = str(ws[chr(ord(cell.column) + 1) + str(cell.row)].value).strip()
                        start, stop, colstart, colstop = cell.row + 1, ws.max_row, cell.column, cell.column
                        breakout = False
                        for stoprow in ws.iter_rows('{}{}:{}{}'.format(colstart, start, colstop, stop)):
                            if breakout:
                                break
                            for stopcell in stoprow:
                                if not stopcell.value:
                                    stop = stopcell.row
                                    breakout = True
                                    break
                                else:
                                    """create a matrix of values for the cells in the range"""
                                    for i, a in enumerate(meta):
                                        offset = ''
                                        if chr(ord(stopcell.column)+i%24) > 'Z':
                                            if offset == '':
                                                offset = 'A'
                                            else:
                                                offset = chr(ord(offset)+1)
                                        newpos = offset+chr(ord(stopcell.column) + i%24) + str(stopcell.row)
                                        val = str(ws[newpos].value).strip()
                                        scheduler_conf[a].append(val)            

            scheduler_conf = {k:v for k,v in scheduler_conf.items() if k != "Scheduling Table"}
            periods = {"daily": "D", "weekly": "W", "monthly": "M", "yearly": "Y"}

            """List of generated columns that are not partitions"""
            added_columns = []
            for i, x in enumerate(tabledef[u"Transformation Logic"]):
                if x == "Standard Field" and tabledef[u"Target Field"][i] not in partitionslist:
                    added_columns.append(tabledef[u"Target Field"][i])
            
            """List of generated columns that are partitions"""
            metadata_fields = defaultdict(dict)
            for a, x in enumerate(tabledef[u"Target Field"]):
                print(x)
                if x not in partitionslist and x not in added_columns:
                    metadata_fields[x] = {"type": tabledef[u"Hadoop/Hive Target Data Type"][a] if u"Hadoop/Hive Target Data Type" in tabledef else tabledef[u"Target Data Type"][a],
                                          "edw_type": tabledef[u"EDW Target Data Type"][a] if u"EDW Target Data Type" in tabledef else "",
                                          "source_field": tabledef[args.source_field][a],
                                          "source_position": tabledef[u"Source Field Position"][
                                              a] if "Source Field Position" in tabledef else "0",
                                          "target_position": tabledef[u"Target Position"][
                                              a] if "Target Position" in tabledef else "0",
                                          "source_format": tabledef[u"Source Data Type Format"][
                                              a].replace("Y", "y").replace("D", "d") if "Source Data Type Format" in tabledef else "yyyyMMdd",
                                          "nullable": "true" if tabledef[u"NULLABLE"][a].lower() == "y" else "false",
                                          "remove_non_printables": "true" if tabledef[u"Remove Non Printable Characters"][a].lower() == "yes" else "false",
                                          "transformations": __get_transformations(tabledef[u"Transformation Logic"][a]) if u"Transformation Logic" in tabledef else ""
                                          }
										  
            """Define the target schema"""
            schema = args.schema if args.schema != "" else (tablemeta[u"Hadoop/Hive Target Production Schema/Database"] if u"Hadoop/Hive Target Production Schema/Database" in tablemeta else tablemeta["Target Production Schema/Database"])

            """Define the date formats for the date fields"""
            formats = dict()
            for a, x in enumerate(tabledef["Target Field"]):
                fmt = tabledef["Source Data Type Format"][a].replace("Y", "y").replace("D", "d")
                if fmt != "None":
                    formats[x] = fmt
            formats['Default'] = "yyyyMMdd"

            """ Define where the reader should start reading the file """
            start_line="0" if ("Specify line number to start file" not in tablemeta or tablemeta["Specify line number to start file"] == "None") else str(int(tablemeta["Specify line number to start file"])-1)
            
            """ Decide which reader the application should use"""
            reader = "StringDelimiterReader"
            if "json" in tablemeta["File Type"]:
                reader = "JSONReader" 
            elif "xls" in tablemeta["File Type"].lower():
                reader = "ExcelReader"

            
            if main_table_ref == u"Hadoop/Hive Target Table": # if we have the newer type
                output_file_loc=tablemeta["Hadoop/Hive Target Schema  Directory HDFS/GPFS"].replace(
                    tablemeta["Hadoop/Hive Target Production Schema/Database"].lower(), schema.lower())
            else:
                output_file_loc=tablemeta["Target Schema  Directory HDFS/GPFS"].replace(
                    tablemeta["Target Production Schema/Database"].lower(), schema.lower())
            
            job_id = tablemeta[main_table_ref]+"_("+sheet + ")_JOB"
            jar_version = tablemeta[u"JAR Version"] if u"JAR Version" in tablemeta else 'default'
            
            staging_schema = tablemeta[u"Hadoop/Hive Target Staging Schema/Database"] if u"Hadoop/Hive Target Staging Schema/Database" in tablemeta else ''
            
            if args.split_broken_lines is not None:
                allow_filtering = True if args.split_broken_lines.lower() == 'true' else False

            if tablemeta["Date format"] == "":
                raise Exception("No file date format specified - please specify a file date format as this is essential for file validation")


            solr_config = """
{{ "JOB_ID":"{job_id}",
    "FileEvalutor":
    {{
        "FS_PREFIX":"/bigpfs",
        "IN_FILE_LOCATION":"{in_file_loc}",
        "IN_PROGRESS_FILE_LOCATION":"{inprogress_file_loc}",
        "REJECT_FILE_LOCATION":"{reject_file_loc}",
        "PERIOD":"{period}",
        "SOURCE":"{source}",
        "FILE_NAME_EXTRACT":"{file_name_extract}",
        "TARGET_FILE_NAME":"{target}",
        "EFFECTIVE_DATE":"{effective_date}"
    }},
    "LOADER_METADATA":
    {{
        "JAR_VERSION":"{jar_version}",
        "READER":"{reader}",
        "FS_PREFIX":"{prefix}",
        "IN_FILE_LOCATION":"{inprogress_file_loc}",
        "OUTPUT_FILE_LOCATION":"{output_file_loc}",
        "ARCHIEVE_FILE_LOCATION":"{archive_file_loc}",
        "REJECT_FILE_LOCATION":"{reject_file_loc}",
        "FAILURE_FILE_LOCATION":"{failure_file_loc}",
        "FILTER_FILE_LOCATION":"{filtered_file_loc}",
        "PARTITIONS":{partitions},
        "ADDED_COLUMNS":{added_cols},
        "TARGET_TABLE":"{target_table}",
        "HAS_HEADER":"{has_header}",
        "COMPARE_HEADER_TO_METADATA":"{compare_header_to_metadata}",
        "CHARSET":"{charset}",
        "DELIMITER":"{delimiter}",
        "FIELDS":{fields},
        "EFFECTIVE_DATE":"{effective_date}",
        "DATE_FORMAT":{formats},
        "FILE_DATE_FORMAT":"{file_date_format}",
        "FILE_DATE_OFFSET":"{file_date_offset}",
        "IGNORE_LINES_NUM":"{line_start}",
        "NULL_VALUE":"{null_value}",
        "SPLIT_TWO_PARTS":"{split_broken_lines}",
        "TEXT_QUALIFIER":"{text_qualifier}",
        "TABLELEVEL_QUALITY_TABLENAME":"{tablelevel_quality_tablename}",
        "COLUMNLEVEL_QUALITY_TABLENAME":"{columnlevel_quality_tablename}",
        "TABLELEVEL_QUALITY_DB_URL":"{quality_db_url}",
        "COLUMNLEVEL_QUALITY_DB_URL":"{quality_db_url}",
        "LINE_DELIMITER":"{line_delimiter}",
        "ROW_COUNT_POSITION":"{monitor_rows}",
        "ROW_COUNT_REGEX":"{count_re}",
        "STAGING_TABLE":"{staging_table}",
        "STAGING_STORED_AS":"{staging_table_stored_as}",
        "STAGING_DIR":"{staging_dir}",
        "EDW_TARGET_TABLE":"{edw_target_table}",
        "EDW_TARGET_DB":"{edw_target_db}"
    }},
    "LOADER_Resource":
    {{
        "APPLICATION_NAME":"{job_id}",
        "MASTER":"yarn-client",
        "NAME_NODE":"{name_node}",
        "CPU_COREs":"4",
        "Memory_Per_Executor":"{executor_memory}",
        "LINE_DELIMITER":"{line_delimiter}"
    }},
    "SCHEDULER_CONF":
    {{
        "SCHEDULER_TYPE":"{scheduler_type}",
        "TOLERANCE":"{tolerance}",
        "ONSUCCESS":"[{onsuccess}]",
        "ONFAILURE":"[{onfailure}]",
        "RUN_TIMES":"{runtimes}"
    }}
}}
            """.format(
                job_id=job_id,
                in_file_loc=tablemeta['HDFS/GPFS Hadoop Landing Path Directory (IN)'].replace("/data", "/"+args.prefix_dir),
                inprogress_file_loc=tablemeta['HDFS/GPFS Hadoop In Progress Path Directory (IN-PROGRESS)'].replace(
                    "/data", "/"+args.prefix_dir),
                reject_file_loc=tablemeta['HDFS/GPFS Hadoop Reject Directory (REJECT)'].replace("/data",
                                                                                                "/" +args.prefix_dir),
                failure_file_loc=tablemeta['HDFS/GPFS Hadoop Failure Directory (FAILURE)'].replace("/data",
                                                                                                   "/" +args.prefix_dir),
                filtered_file_loc=tablemeta['HDFS/GPFS Hadoop Filtered Directory (FILTERED)'].replace("/data",
                                                                                                      "/" +args.prefix_dir),
                period=periods[tablemeta['Define the Schedule of loading  - Calendar, HOURLY INTRADAY DAILY WEEKLY MONTHLY QUARTERLY YEARLY ADJUSTMENT'].lower()],
                source=tablemeta["Source Filename"].replace("<", "_<").split("_")[0],
                file_name_extract=__get_solr_filename_extract(tablemeta),
                target=__get_solr_target_filename(tablemeta),
                effective_date=datetime.datetime.today().strftime("%Y-%m-%d"),
                output_file_loc=output_file_loc,
                jar_version=jar_version,
                reader=reader,
                archive_file_loc=tablemeta["HDFS/GPFS Hadoop Archive Directory (ARCHIVE)"].replace("/data",
                                                                                                   "/" +args.prefix_dir),
                partitions=__get_solr_columns(tablemeta, tabledef, partitionslist),
                added_cols=__get_solr_columns(tablemeta, tabledef, added_columns, partition=False),
                target_table=schema + "." + tablemeta[main_table_ref],
                delimiter="," if tablemeta["File Delimeter"] in ["TBD", "TBC"] else tablemeta["File Delimeter"].replace("|","\\\\|").replace('"','\\"'),
                fields=json.dumps(metadata_fields),
                charset="ISO-8859-1" if tablemeta[
                                            'What is the encoding standard of incoming file e.g. utf-8, ascii etc.'].lower() == "ascii" else
                tablemeta['What is the encoding standard of incoming file e.g. utf-8, ascii etc.'],
                has_header="true" if tablemeta["File Headers"].lower() == "yes" else "false",
                prefix="/"+args.fs_prefix if args.fs_prefix != "" else "",
                name_node=args.name_node,
                formats=json.dumps(formats),
                file_date_format=tablemeta["Date format"],
                file_date_offset=tablemeta["File Date Offset"] if "File Date Offset" in tablemeta and tablemeta["Compare Header to Metadata?"] != "" else "0",
                compare_header_to_metadata="false" if "Compare Header to Metadata?" in tablemeta and tablemeta["Compare Header to Metadata?"].lower() == "no" else "true",
                line_start=start_line,
                null_value="" if "Null Value" not in tablemeta or tablemeta["Null Value"] == "None" else tablemeta["Null Value"].replace('\"','\\"'),
                split_broken_lines="true" if allow_filtering else "false",
                text_qualifier="" if tablemeta["Text Qualifier Characters"] == "None" else tablemeta["Text Qualifier Characters"].replace('\"','\\"').replace(' ',''),
                tablelevel_quality_tablename=schema+"."+args.tablelevel_quality_tablename,
                columnlevel_quality_tablename=schema+"."+args.columnlevel_quality_tablename,
                line_delimiter=tablemeta["Lines Terminated by"].replace("\\","") if "Lines Terminated by" in tablemeta and tablemeta["Lines Terminated by"] != "None" else "n",
                scheduler_type=tablemeta["Scheduler                       Types: Sched,Cron,Tws,Other"] if "Scheduler                       Types: Sched,Cron,Tws,Other" in tablemeta and tablemeta["Scheduler                       Types: Sched,Cron,Tws,Other"] != None else "",
                tolerance=tablemeta["Tolerance"] if "Tolerance" in tablemeta and tablemeta["Tolerance"] != "None" else "",
                onsuccess=tablemeta["OnSuccess"] if "OnSuccess" in tablemeta and tablemeta["OnSuccess"] != "None" else "",
                onfailure=tablemeta["OnFailure"] if "OnFailure" in tablemeta and tablemeta["OnFailure"] != "None" else "",
                runtimes=json.dumps(scheduler_conf).replace('"','\\"'),
                executor_memory=args.executor_memory,
                monitor_rows=monitor_rows,
                count_re=count_re,
                quality_db_url="jdbc:db2://{hostname}:{port}/BIGSQL:user={username};password=".format(hostname=args.quality_hostname,port=args.quality_port,username=args.quality_user),
                staging_table = staging_schema+'.' + tablemeta[u"Hadoop/Hive Target Staging Table"] if u"Hadoop/Hive Target Staging Table" in tablemeta else "",
                staging_table_stored_as = tablemeta[u"Target Staging Data Stored as"] if u"Target Staging Data Stored as" in tablemeta else "",
                staging_dir = tablemeta[u"Hadoop/Hive Target Staging Directory HDFS/GPFS"] if u"Hadoop/Hive Target Staging Directory HDFS/GPFS" in tablemeta else "",
                edw_target_table = tablemeta[u"EDW Target Table"] if u"EDW Target Table" in tablemeta else "",
                edw_target_db = tablemeta[u"EDW Target Schema/Database"] if u"EDW Target Schema/Database" in tablemeta else ""
            )

            solr_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "SOLR")
            os.makedirs(solr_dir, exist_ok=True)
            
            outname = tablemeta[main_table_ref] + "_solr_config.json"
            if u"Multi Target Table" in  tablemeta:
                if tablemeta[u"Multi Target Table"].lower() == 'yes':
                    outname = job_id + "_solr_config.json"
            
            with open(os.path.join(solr_dir, outname), "w") as f:
                print('Writing solr configuration to ' + os.path.join(solr_dir, outname))
                f.write(solr_config)
