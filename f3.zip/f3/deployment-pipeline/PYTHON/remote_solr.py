# -*- coding: utf-8 -*-
"""
Created on Mon Feb 13 2017

@author: Colm Coughlan. Data Science and Solutions. 40631

Tested only on python3

"""

import argparse
import glob
from xml.sax.saxutils import escape
import requests
import jks


parser = argparse.ArgumentParser(description='Post json to solr as xml on remote.')
parser.add_argument('solr_url', type=str, help='Solr URL')
parser.add_argument('files', type=str, help='Files')
parser.add_argument('--jceks', type=str, help='jceks location. leave empty for unsecured access')
parser.add_argument('--jceks_pass', type=str, help='jceks password. leave empty for default')

args = parser.parse_args()  # get args

if args.jceks is None:
    jceks_location = ''
else:
    jceks_location = args.jceks
    
if args.jceks_pass is None:
    jceks_pass = 'none'
else:
    jceks_pass = args.jceks_pass

files = glob.glob(args.files)

if len(files) == 0:
    print('Error: No files found at '+args.files)
    raise(Exception)

xml = '''<add>'''

for cfile in files:
    data = open(cfile, encoding='ISO-8859-1').read()
    doc_id = ((data.split('JOB_ID":"')[1]).split("\"")[0])  # get doc id from json
    data = escape(data, {'¦': '0xA6', '"': '&quot;'})
    xml = xml + '''
    <doc><field name="id">''' + doc_id + '''</field><field name="conf">''' + data + '''</field></doc>'''

xml = xml + '''</add>'''

headers = {"Content-Type": "text/xml"}
if jceks_location != '':
    ks = jks.KeyStore.load(jceks_location,jceks_pass).secret_keys
    ks_user = 'solr.user.write'
    ks_pass = 'solr.password.write'
    cauth = requests.auth.HTTPBasicAuth(ks[ks_user].key.decode('utf-8'), ks[ks_pass].key.decode('utf-8') )
    resp = requests.post(args.solr_url, auth = cauth, data = xml, headers=headers)
else:
    resp = requests.post(args.solr_url, data = xml, headers=headers)
    
resp.raise_for_status()