.. Data Science and Solutions Python Library documentation master file, created by
   sphinx-quickstart.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Data Science and Solutions Python Library documentation.
==============================================

Welcome to the Data Science and Solutions library.

You can install this library by cloning the from `git master branch <https://gitstash.aib.pri/projects/DI/repos/dss-python-library/browse>`_. Then use pip to install it from its directory with the command:
::
	pip install . --upgrade

Dsspy currently contains 3 modules: connections, load and products. Connections contains connection routines for BigSQL, SQL, and solr, as well as an SSH class. IO contains routines for local IO. Utilities contains generally useful functions.

.. toctree::
   :maxdepth: 2


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
