# -*- coding: utf-8 -*-
"""
Created on Fri May 26 10:20:15 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""



import pandas as pd
import os
from subprocess import Popen
import glob
import warnings


try:
    import win32com.client
except:
    warnings.warn('dsslib: No win32 module found. win32 functionality unavailable', ImportWarning)
    have_win32 = False
else:
    have_win32 = True

xlApp = win32com.client.Dispatch("Excel.Application")

def load_excel_with_password(filename, password):
    '''
    Read an excel file with a password using external Win32 API
    
    :param str filename: Name of excel file
    :param str password: Password
    :return: List of dataframes (one for each sheet)
    '''
    try:
        xlwb = xlApp.Workbooks.Open(filename, False, True, None, password)
    except Exception as e:
        raise Exception('Error: have you the right password? Try closing the excel sheet too.')
    dfa = []
    for xlws in xlwb.Sheets:
        cols = list((xlws.Range(xlws.Cells(1, 1), xlws.Cells(1, xlws.UsedRange.Rows(1).Columns.Count)).Value)[0])

        content = xlws.Range(xlws.Cells(1, 1), xlws.Cells(xlws.UsedRange.Rows.Count, xlws.UsedRange.Columns.Count)).Value 
        dfa.append(pd.DataFrame(list(content)[1:], columns = cols))
    
    return dfa
def load_zip_with_password(swipe_file_locations, password, fileext = 'csv',zip_exec = 'C:\\Program Files\\7-Zip\\7z.exe', skip_rows = 1):
    '''
    Unfortunately, python's ZipFile only supports zip files encrypted with CRC32 encryption. Need to use external program (7zip)
    
    :param str swipe_file_locations: Folder containing zip files
    :param str password: Password
    :param str fileext: Extension of csv file (default = csv)
    :param str zip_exec: Location of zip extractor (default = 'C:\\Program Files\\7-Zip\\7z.exe')
    :param str skip_rows: Number of rows to skip after header (default = 1)
    :return: Single concatenated dataframe
    '''
    
    cwd = os.getcwd()
    os.chdir(swipe_file_locations)
    
    dfa = []
    
    for root, dirs, files in os.walk(swipe_file_locations):
        for file in files:
            if file.split('.')[-1] == 'zip':
                cmd = zip_exec + ' e -p'+password+' '+os.path.join(root, file)
                print('Loading data for file '+file)
                proc = Popen(cmd)
                proc.communicate()
                innerfile = glob.glob(swipe_file_locations + '\\*' +fileext)
                if len(innerfile) !=1:
                    print(innerfile)
                    raise Exception('More than one '+fileext+' file detected in '+swipe_file_locations + ''+fileext+'!')
                dfa.append( pd.read_csv( innerfile[0], encoding = 'cp850').ix[skip_rows:])
                os.remove(innerfile[0])
    
    os.chdir(cwd)
    
    return pd.concat(dfa), len(dfa)