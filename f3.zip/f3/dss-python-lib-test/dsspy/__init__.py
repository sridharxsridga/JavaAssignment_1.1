# -*- coding: utf-8 -*-
"""

@author: Colm Coughlan. Data Science and Solutions. 40631

This is the Data Science and Solutions python library
"""