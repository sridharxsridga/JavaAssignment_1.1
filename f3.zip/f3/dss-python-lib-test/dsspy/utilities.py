# -*- coding: utf-8 -*-
"""
Created on Fri May 26 11:18:32 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

import pandas as pd
import multiprocessing as mp
import traceback
from subprocess import check_output


class ProcessWithExceptionHandling(mp.Process):
    def __init__(self, *args, **kwargs):
        mp.Process.__init__(self, *args, **kwargs)
        self._pconn, self._cconn = mp.Pipe()
        self._exception = None

    def run(self):
        try:
            mp.Process.run(self)
            self._cconn.send(None)
        except Exception as e:
            tb = traceback.format_exc()
            self._cconn.send((e, tb))
            # raise e  # You can still rise this exception if you need to

    @property
    def exception(self):
        if self._pconn.poll():
            self._exception = self._pconn.recv()
        return self._exception
        
def hdfs_op(operation,origin, target=None):
    if operation == 'mv':
        cmd_str = 'hadoop fs -mv '+origin+' '+target
        output = check_output(cmd_str, shell=True).decode('ascii').split('\n')[1:]
    elif operation == 'ls':
        cmd_str = 'hadoop fs -ls '+origin
        output = check_output(cmd_str, shell=True).decode('ascii').split('\n')[1:]
        files = []
        for line in output:
            tlist = line.split()
            if len(tlist) > 0:
                files.append(tlist[-1])
        return files
    else:
        raise(Exception('Unsupported HDFS operation: '+operation))

def excelgroup(df, groupcols, outfile, selcol = 'Staff ID', excel_writer = None, sheet_name = None):
    '''
    Save a group or groups from a pandas dataframe to a sheet in an excel file.
    Supports writing to multiple sheets
    Note: You should manually close the excel writer with a .close() call after using this function - unless you need to reuse the writer
    
    :param dataframe df: Input dataframe
    :param str/list(str) groupcols: Column(s) to group on
    :param str outfile: Name of output file. Can include full path.
    :param str selcol: Column to select after grouping.
    :param excel_writer excel_writer: Excel writer object from previous call, if writing multiple sheets. Leave blank to start a new sheet.
    :param str sheet_name: Name to use for sheet. Leave emtpy for automatic name. Excel has a max of 31 chars for sheet name.
    :return: excel_writer
    '''    
    
    group = pd.DataFrame(df.groupby(groupcols).count()[selcol])#  make a collapsed plot
    
    #excel tab name has a limit of 31 characters so if combination of column names is longer, need to manually enter one
    if sheet_name == None:
        if not(isinstance(groupcols, str)):
            sheet_name = '_'.join(groupcols)
        else:
            sheet_name = groupcols

    if excel_writer == None:
        excel_writer = pd.ExcelWriter(outfile)
    
    group.to_excel(excel_writer, sheet_name.replace(' ','_'), header = ['Count']) # save the plot data here
    
    return excel_writer